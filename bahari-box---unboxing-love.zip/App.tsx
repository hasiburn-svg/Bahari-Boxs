
import React, { useState, useEffect, useMemo } from 'react';
import Homepage from './components/Homepage';
import Assistant from './components/Assistant';
import WhatsAppButton from './components/WhatsAppButton';
import LoginPanel from './components/LoginPanel';
import CartDrawer from './components/CartDrawer';
import WishlistDrawer from './components/WishlistDrawer';
import CheckoutPanel from './components/CheckoutPanel';
import TrackOrderPanel from './components/TrackOrderPanel';
import QuickViewModal from './components/QuickViewModal';
import AdminPanel from './components/AdminPanel';
import { PRODUCTS as INITIAL_PRODUCTS, INITIAL_CATEGORIES } from './constants';
import { Product, CartItem, SiteConfig, Category } from './types';
import { translations, Language } from './translations';
import { Settings } from 'lucide-react';

const MaintenanceScreen = ({ onBypass }: { onBypass: () => void }) => (
  <div className="fixed inset-0 z-[2000] bg-black flex flex-col items-center justify-center text-center p-6 animate-in fade-in duration-1000">
    <div className="w-24 h-24 bg-[#5b2b4d] rounded-full flex items-center justify-center mb-8 animate-pulse shadow-[0_0_50px_rgba(91,43,77,0.5)]">
      <Settings size={40} className="text-white animate-[spin_10s_linear_infinite]" />
    </div>
    <h1 className="text-4xl md:text-6xl font-serif italic text-[#F4EBD0] mb-6">System Maintenance</h1>
    <p className="text-zinc-500 text-sm tracking-widest uppercase max-w-md leading-loose">
      Our artisans are currently curating the next collection. <br/>
      The boutique will reopen shortly.
    </p>
    {/* Hidden backdoor for admin access */}
    <button onClick={onBypass} className="absolute bottom-10 right-10 w-4 h-4 bg-transparent hover:bg-[#5b2b4d]/20 rounded-full transition-colors cursor-default"></button>
  </div>
);

const App: React.FC = () => {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('bahari_lang') as Language) || 'en';
  });
  
  // App-level State for Products and Orders - Using v2 keys to reset site
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bahari_products_v2');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('bahari_categories_v2');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [orders, setOrders] = useState<any[]>(() => {
    const saved = localStorage.getItem('bahari_orders_v2');
    return saved ? JSON.parse(saved) : [];
  });

  // CMS / Site Config State
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('bahari_config_v2');
    const defaultConfig = {
      theme: {
        primary: '#5b2b4d',    // Default Plum
        secondary: '#F4EBD0',  // Default Champagne
        background: '#050505', // Default Noir
        surface: '#0c0c0e',
      },
      content: {
        heroTitle: 'Curated Elegance',
        heroSubtitle: 'for the heart',
        heroImage: 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=2000&auto=format&fit=crop',
        announcement: 'Unboxing Love • Dhaka',
      },
      features: {
        enableChat: true,
        showRitual: true,
        maintenanceMode: false,
      },
      delivery: {
        insideDhaka: 80,
        outsideDhaka: 120,
        freeThreshold: 15000
      },
      payment: {
        bkash: '01700-000000',
        nagad: '01800-000000',
        rocket: '01900-000000-1',
        upay: '01600-000000'
      }
    };

    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...defaultConfig,
        ...parsed,
        features: { ...defaultConfig.features, ...(parsed.features || {}) },
        delivery: { ...defaultConfig.delivery, ...(parsed.delivery || {}) },
        payment: { ...defaultConfig.payment, ...(parsed.payment || {}) }
      };
    }
    return defaultConfig;
  });

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('bahari_products_v2', JSON.stringify(products));
    localStorage.setItem('bahari_categories_v2', JSON.stringify(categories));
    localStorage.setItem('bahari_orders_v2', JSON.stringify(orders));
    localStorage.setItem('bahari_config_v2', JSON.stringify(siteConfig));
  }, [products, categories, orders, siteConfig]);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackOrderOpen, setIsTrackOrderOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  const t = (key: keyof typeof translations.en) => {
    return translations[language][key] || translations.en[key];
  };

  const addToCart = (product: Product) => {
    if (product.stock === 0) return;
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const updateCartNote = (id: string, note: string) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, note };
      }
      return item;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]);
  };

  const wishlistProducts = useMemo(() => {
    return products.filter(p => wishlist.includes(p.id));
  }, [wishlist, products]);

  const handleOrderComplete = () => {
    const total = cart.reduce((acc, i) => acc + i.price * i.quantity, 0); 
    const newOrder = {
      id: `BB-${Math.floor(100000 + Math.random() * 900000)}`,
      customer: 'Guest Patron',
      total: total + siteConfig.delivery.insideDhaka, 
      status: 'Processing',
      date: new Date().toISOString().split('T')[0]
    };
    
    setOrders([newOrder, ...orders]);
    setProducts(prev => prev.map(p => {
      const cartItem = cart.find(ci => ci.id === p.id);
      if (cartItem) {
        return { ...p, stock: Math.max(0, p.stock - cartItem.quantity), sold: p.sold + cartItem.quantity };
      }
      return p;
    }));

    setCart([]);
    setIsCheckoutOpen(false);
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Dynamic Theme Injection
  const dynamicStyles = `
    :root {
      --brand-plum: ${siteConfig.theme.primary};
      --brand-champagne: ${siteConfig.theme.secondary};
      --brand-noir: ${siteConfig.theme.background};
      --brand-surface: ${siteConfig.theme.surface};
    }
  `;

  return (
    <div className="min-h-screen selection:bg-[var(--brand-champagne)] selection:text-[var(--brand-plum)]" style={{ backgroundColor: 'var(--brand-noir)', color: 'white' }}>
      <style>{dynamicStyles}</style>
      
      {siteConfig.features.maintenanceMode && !isAdminOpen ? (
        <MaintenanceScreen onBypass={() => setIsAdminOpen(true)} />
      ) : (
        <Homepage 
          products={products}
          categories={categories} 
          onOpenAdmin={() => setIsAdminOpen(true)} 
          onAddToCart={addToCart}
          cartCount={cartCount}
          wishlistCount={wishlist.length}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => setIsWishlistOpen(true)}
          onToggleWishlist={toggleWishlist}
          wishlistIds={wishlist}
          onQuickView={(p) => setQuickViewProduct(p)}
          config={siteConfig}
        />
      )}
      
      {/* Admin Panel (CMS) */}
      {isAdminOpen && (
        <AdminPanel 
          onClose={() => setIsAdminOpen(false)} 
          products={products} 
          setProducts={setProducts}
          categories={categories}
          setCategories={setCategories} 
          orders={orders}
          setOrders={setOrders}
          siteConfig={siteConfig}
          setSiteConfig={setSiteConfig}
        />
      )}

      {/* Overlays - Only render if not in maintenance mode or if bypassed by admin */}
      {(!siteConfig.features.maintenanceMode || isAdminOpen) && (
        <>
          <QuickViewModal product={quickViewProduct} onClose={() => setQuickViewProduct(null)} onAddToCart={addToCart} t={t} />
          {siteConfig.features.enableChat && (
            <Assistant cartItems={cart} isOpen={isAssistantOpen} onClose={() => setIsAssistantOpen(false)} onOpen={() => setIsAssistantOpen(true)} />
          )}
          <WhatsAppButton />
          <LoginPanel isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} t={t} />
          <CartDrawer 
            isOpen={isCartOpen} 
            onClose={() => setIsCartOpen(false)} 
            items={cart} 
            onUpdateQuantity={updateCartQuantity} 
            onUpdateNote={updateCartNote}
            onRemove={removeFromCart} 
            onCheckout={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }} 
            onAddToCart={addToCart} 
            t={t} 
            config={siteConfig}
          />
          <WishlistDrawer isOpen={isWishlistOpen} onClose={() => setIsWishlistOpen(false)} items={wishlistProducts} onRemove={toggleWishlist} onMoveToCart={addToCart} t={t} />
          <CheckoutPanel isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} items={cart} onComplete={handleOrderComplete} t={t} config={siteConfig} />
          <TrackOrderPanel isOpen={isTrackOrderOpen} onClose={() => setIsTrackOrderOpen(false)} t={t} />
        </>
      )}
    </div>
  );
};

export default App;
