
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  gallery?: string[];
  rating: number;
  reviews: number;
  stock: number;
  sold: number;
  isNew?: boolean;
  isHot?: boolean;
  description?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  count?: number;
}

export interface CartItem extends Product {
  quantity: number;
  note?: string;
}

export interface SiteConfig {
  theme: {
    primary: string;    // Brand Plum
    secondary: string;  // Brand Champagne/Gold
    background: string; // Brand Noir
    surface: string;    // Card Backgrounds
  };
  content: {
    heroTitle: string;
    heroSubtitle: string;
    heroImage: string;
    announcement: string;
  };
  features: {
    enableChat: boolean;
    showRitual: boolean;
    maintenanceMode: boolean;
  };
  delivery: {
    insideDhaka: number;
    outsideDhaka: number;
    freeThreshold: number;
  };
  payment: {
    bkash: string;
    nagad: string;
    rocket: string;
    upay: string;
  };
}
