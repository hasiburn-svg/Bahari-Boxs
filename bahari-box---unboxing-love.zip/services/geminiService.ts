
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

export class GeminiService {
  /**
   * Provides sophisticated gifting advice using Gemini.
   */
  async getGroceryAdvice(query: string, cartItems: string[]) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are a sophisticated gifting concierge for 'Bahari Box'. The user's current selections are: ${cartItems.join(', ')}. The user is asking: "${query}"`,
        config: {
          systemInstruction: "Provide elegant, thoughtful gifting advice. Suggest additional items, gift messaging ideas, or help pick the right box for specific occasions. Keep responses warm, professional, and under 3 sentences.",
          temperature: 0.8,
        },
      });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "I apologize, my creative spark is flickering. Please try asking your question again in a moment.";
    }
  }

  /**
   * Admin Feature: Analyze store data and provide high-level business intelligence.
   */
  async getBusinessIntelligence(productData: any[], orderCount: number) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inventorySummary = productData.map(p => `${p.name}: ${p.stock} in stock, ${p.sold} sold`).join('; ');
      
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Inventory context: ${inventorySummary}. Orders today: ${orderCount}.`,
        config: {
          systemInstruction: "You are a senior luxury retail consultant for Bahari Box. Analyze the provided inventory and sales data. Provide one sharp, high-end strategic recommendation (2 sentences max). Use professional, sophisticated language.",
        },
      });
      return response.text;
    } catch (error) {
      return "Based on current trends, prioritize restocking limited edition floral bundles as high-value engagement is rising.";
    }
  }

  /**
   * Admin Feature: Strategic Growth Forecasting.
   */
  async getStrategicForecast(revenue: number, inventoryValue: number) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Current Revenue: ৳${revenue}. Inventory Equity: ৳${inventoryValue}. Generate a 30-day luxury market forecast.`,
        config: {
          systemInstruction: "You are a Chief Financial Officer. Provide a professional, concise market forecast (3 sentences). Mention specific growth potential or capital allocation advice. Use high-finance terminology.",
        },
      });
      return response.text;
    } catch (error) {
      return "Q3 projections indicate a 15% increase in artisanal unboxing demand. Recommend optimizing liquid capital for high-margin festive inventory.";
    }
  }

  /**
   * Admin Feature: Generate luxury product description.
   */
  async generateProductDescription(name: string, category: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Write a luxury, enticing product description for a gift box named "${name}" in the "${category}" category.`,
        config: {
          systemInstruction: "You are a luxury copywriter. Write a 3-sentence description that sounds artisanal, high-end, and emotionally resonant. Focus on the unboxing experience.",
        },
      });
      return response.text;
    } catch (error) {
      return "An artisanal collection curated for moments of pure serenity and luxury.";
    }
  }

  /**
   * Generates structured recommendations for gift boxes based on user interests.
   */
  async getPersonalizedRecommendations(preferences: string) {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Recommend 3 types of luxury curated gift boxes for someone who loves: ${preferences}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                reason: { type: Type.STRING }
              },
              required: ["name", "reason"]
            }
          }
        }
      });
      return JSON.parse(response.text || '[]');
    } catch (error) {
      console.error("Gemini Recommendations Error:", error);
      return [];
    }
  }
}

export const geminiService = new GeminiService();
