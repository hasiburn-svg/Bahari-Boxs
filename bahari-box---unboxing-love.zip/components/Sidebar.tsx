
import React from 'react';
import { ChevronRight } from 'lucide-react';
import { INITIAL_CATEGORIES, getCategoryIcon } from '../constants';
import { translations, Language } from '../translations';

interface SidebarProps {
  activeCategory: string | null;
  onSelectCategory: (name: string | null) => void;
  lang: Language;
  t: (key: keyof typeof translations.en) => string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeCategory, onSelectCategory, lang, t }) => {
  return (
    <div className="w-full bg-white border border-t-0 rounded-b-3xl shadow-sm hidden lg:block overflow-hidden">
      <ul className="py-2">
        <li className={`group border-b border-slate-50 last:border-0 ${!activeCategory ? 'bg-purple-50/50' : ''}`}>
          <button 
            onClick={() => onSelectCategory(null)}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-purple-50 transition-all duration-300"
          >
            <div className={`flex items-center gap-3 font-bold text-xs uppercase tracking-widest ${!activeCategory ? 'text-[#5b2b4d]' : 'text-slate-500'}`}>
              <ChevronRight size={14} className={!activeCategory ? 'translate-x-1' : 'group-hover:translate-x-1 transition-transform'} /> 
              {t('all_collections')}
            </div>
          </button>
        </li>
        {INITIAL_CATEGORIES.map((cat) => {
          const catKey = `cat_${cat.id === '1' ? 'signature' : cat.id === '2' ? 'spa' : cat.id === '3' ? 'brews' : cat.id === '4' ? 'serenity' : cat.id === '5' ? 'romantic' : cat.id === '6' ? 'floral' : cat.id === '7' ? 'artisan' : 'celebration'}` as keyof typeof translations.en;
          const isActive = activeCategory === cat.name;
          
          return (
            <li key={cat.id} className={`group border-b border-slate-50 last:border-0 ${isActive ? 'bg-purple-50/50' : ''}`}>
              <button 
                onClick={() => onSelectCategory(cat.name)}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-purple-50 transition-all duration-300"
              >
                <div className={`flex items-center gap-3 transition-colors ${isActive ? 'text-[#5b2b4d]' : 'text-slate-600 group-hover:text-[#5b2b4d]'}`}>
                  <span className={`transition-transform duration-500 ${isActive ? 'text-[#5b2b4d] scale-110' : 'text-purple-300 group-hover:text-[#5b2b4d]'}`}>
                    {getCategoryIcon(cat.icon)}
                  </span>
                  <span className={`text-[13px] font-semibold ${isActive ? 'text-[#5b2b4d]' : ''}`}>{t(catKey) || cat.name}</span>
                </div>
                <ChevronRight size={16} className={`transition-all duration-300 ${isActive ? 'text-[#5b2b4d] translate-x-1 opacity-100' : 'text-slate-200 opacity-0 group-hover:opacity-100 group-hover:translate-x-1'}`} />
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Sidebar;
