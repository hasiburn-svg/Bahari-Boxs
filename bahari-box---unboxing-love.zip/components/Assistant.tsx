
import React, { useState, useEffect, useRef } from 'react';
import { Bot, Send, X, Minimize2, Maximize2, Loader2, Sparkles, Gift } from 'lucide-react';
import { geminiService } from '../services/geminiService';
import { CartItem } from '../types';

interface AssistantProps {
  cartItems: CartItem[];
  isOpen: boolean;
  onClose: () => void;
  onOpen: () => void;
}

const Assistant: React.FC<AssistantProps> = ({ cartItems, isOpen, onClose, onOpen }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: "Welcome to Bahari Box. I'm your Personal Gifting Concierge. How can I help you share some love today?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    const cartNames = cartItems.map(i => i.name);
    const response = await geminiService.getGroceryAdvice(`GIFTING QUERY: ${userMsg}`, cartNames);
    
    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  if (!isOpen) {
    return (
      <button 
        onClick={onOpen}
        className="fixed bottom-8 right-8 bg-[#5b2b4d] text-white p-5 rounded-full shadow-2xl hover:bg-[#4a233f] transition-all z-50 flex items-center gap-3 group border-4 border-white shadow-[0_0_20px_rgba(91,43,77,0.3)]"
      >
        <Sparkles size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 whitespace-nowrap font-bold text-sm tracking-widest uppercase">Concierge</span>
      </button>
    );
  }

  return (
    <div className={`fixed right-8 transition-all duration-500 z-50 bg-white shadow-2xl rounded-[2rem] border-2 border-purple-50 flex flex-col overflow-hidden ${isMinimized ? 'bottom-8 w-72 h-16' : 'bottom-8 w-[400px] h-[600px]'}`}>
      {/* Header */}
      <div className="bg-[#5b2b4d] p-5 text-white flex items-center justify-between cursor-pointer" onClick={() => isMinimized && setIsMinimized(false)}>
        <div className="flex items-center gap-3">
          <Gift size={20} className="text-purple-300" />
          <div className="flex flex-col">
            <span className="font-bold text-sm tracking-tight">Bahari Concierge</span>
            <span className="text-[9px] uppercase tracking-widest text-purple-300 opacity-80">Personal Stylist</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={(e) => { e.stopPropagation(); setIsMinimized(!isMinimized); }} className="hover:text-purple-300 transition-colors">
            {isMinimized ? <Maximize2 size={18} /> : <Minimize2 size={18} />}
          </button>
          <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="hover:text-purple-300 transition-colors">
            <X size={18} />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div ref={scrollRef} className="flex-1 p-6 overflow-y-auto space-y-6 custom-scrollbar bg-purple-50/20">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-[#5b2b4d] text-white rounded-tr-none shadow-md' : 'bg-white border-2 border-purple-50 text-gray-700 rounded-tl-none shadow-sm'}`}>
                  {m.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border-2 border-purple-50 p-4 rounded-2xl rounded-tl-none shadow-sm">
                  <Loader2 className="animate-spin text-[#5b2b4d]" size={20} />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-6 border-t border-purple-50 bg-white">
            <div className="flex gap-3">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="How can I help you today?"
                className="flex-1 border-2 border-purple-50 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:border-[#5b2b4d]/30 transition-all"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="bg-[#5b2b4d] text-white p-3 rounded-2xl hover:bg-[#4a233f] disabled:opacity-50 shadow-lg shadow-[#5b2b4d]/20 transition-all active:scale-95"
              >
                <Send size={20} />
              </button>
            </div>
            <p className="text-center text-[10px] text-gray-400 mt-4 uppercase tracking-widest font-bold">Curated by AI Studio</p>
          </div>
        </>
      )}
    </div>
  );
};

export default Assistant;
