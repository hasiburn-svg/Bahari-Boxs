
import React, { useState, useEffect } from 'react';
import { Search, ShoppingCart, User, Heart, Menu, ChevronDown, Gift, Sparkles, ChevronRight, X } from 'lucide-react';
import { INITIAL_CATEGORIES, getCategoryIcon } from '../constants';
import { Language, translations } from '../translations';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onSearchChange: (query: string) => void;
  onToggleMenu: () => void;
  onSelectCategory: (name: string | null) => void;
  selectedCategory: string | null;
  onOpenConcierge: () => void;
  onScrollToJournal: () => void;
  onOpenLogin: () => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenTrackOrder: () => void;
  lang: Language;
  onLangChange: (lang: Language) => void;
  t: (key: keyof typeof translations.en) => string;
}

const Header: React.FC<HeaderProps> = ({ 
  cartCount, 
  wishlistCount, 
  onSearchChange, 
  onToggleMenu, 
  onSelectCategory,
  selectedCategory,
  onOpenConcierge,
  onScrollToJournal,
  onOpenLogin,
  onOpenCart,
  onOpenWishlist,
  onOpenTrackOrder,
  lang,
  onLangChange,
  t
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white/80 backdrop-blur-xl border-b border-slate-200 shadow-sm' : 'bg-white'}`}>
      {/* Upper Utility Bar */}
      <div className={`border-b border-slate-50 transition-all duration-500 overflow-hidden ${scrolled ? 'h-0 opacity-0' : 'h-10 opacity-100'}`}>
        <div className="container mx-auto px-6 h-full flex justify-between items-center">
          <div className="flex items-center gap-6 text-[10px] uppercase tracking-[0.2em] font-semibold text-slate-400">
            <span className="flex items-center gap-1.5"><Sparkles size={10} className="text-purple-400" /> {t('wrap')}</span>
            <span className="hidden md:inline-block w-px h-3 bg-slate-200"></span>
            <span className="hidden md:flex items-center gap-1.5">{t('nationwide')}</span>
          </div>
          <div className="flex items-center gap-6 text-[10px] uppercase tracking-[0.2em] font-semibold text-slate-400">
            <button onClick={onOpenTrackOrder} className="hover:text-[#5b2b4d] transition-colors">{t('track')}</button>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => onLangChange('en')} 
                className={`transition-colors ${lang === 'en' ? 'text-[#5b2b4d] font-bold' : 'hover:text-[#5b2b4d]'}`}
              >
                EN
              </button>
              <span className="w-px h-2 bg-slate-300"></span>
              <button 
                onClick={() => onLangChange('bn')} 
                className={`transition-colors ${lang === 'bn' ? 'text-[#5b2b4d] font-bold' : 'hover:text-[#5b2b4d]'}`}
              >
                বাং
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Branding Bar */}
      <div className="container mx-auto px-6 py-4 lg:py-6 flex items-center justify-between">
        <div className="flex items-center gap-6 lg:w-1/3">
          <button onClick={onToggleMenu} className="lg:hidden p-2 -ml-2"><Menu size={20} /></button>
          <div className="hidden lg:flex items-center w-full max-w-[280px] relative">
            <input 
              type="text" 
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="..." 
              className="w-full bg-slate-50 border border-slate-100 rounded-full py-2 px-5 pl-11 text-xs focus:outline-none focus:ring-4 focus:ring-[#5b2b4d]/5"
            />
            <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          </div>
        </div>

        <div className="flex flex-col items-center cursor-pointer group" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <h1 className="text-2xl lg:text-3xl font-bold text-[#5b2b4d] tracking-[-0.03em]">Bahari<span className="serif italic ml-1">Box</span></h1>
          <span className="text-[9px] uppercase tracking-[0.5em] font-bold text-slate-300">Dhaka • Chattogram • Sylhet</span>
        </div>

        <div className="flex items-center justify-end gap-2 lg:gap-6 lg:w-1/3">
          <div className="flex items-center gap-1 lg:gap-3">
            <button onClick={onOpenLogin} className="p-2.5 text-slate-600 hover:text-[#5b2b4d]"><User size={20} /></button>
            <button onClick={onOpenWishlist} className="relative p-2.5 text-slate-600 hover:text-rose-500">
              <Heart size={20} className={wishlistCount > 0 ? "fill-rose-500 text-rose-500" : ""} />
              {wishlistCount > 0 && <span className="absolute top-2 right-2 bg-rose-500 text-white text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-black">{wishlistCount}</span>}
            </button>
            <button onClick={onOpenCart} className="relative p-2.5 text-slate-600 hover:text-[#5b2b4d]">
              <ShoppingCart size={20} />
              {cartCount > 0 && <span className="absolute top-2 right-2 bg-[#5b2b4d] text-white text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-black">{cartCount}</span>}
            </button>
          </div>
        </div>
      </div>

      <nav className="border-t border-slate-50 hidden md:block">
        <div className="container mx-auto px-6 flex items-center justify-center gap-10 py-4">
          {[
            { label: t('boutique'), action: () => window.scrollTo({top: document.getElementById('boutique-section')?.offsetTop || 0, behavior: 'smooth'}) },
            { label: t('curated'), action: () => onSelectCategory('Signature Boxes') },
            { label: t('build_box'), action: () => onSelectCategory('Signature Boxes') },
            { label: t('journal'), action: onScrollToJournal },
            { label: t('concierge'), action: onOpenConcierge }
          ].map((item, idx) => (
            <button 
              key={idx}
              onClick={item.action}
              className="text-[11px] uppercase tracking-[0.2em] font-bold text-slate-500 hover:text-[#5b2b4d] transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </nav>
    </header>
  );
};

export default Header;
