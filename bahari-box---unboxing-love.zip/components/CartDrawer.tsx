
import React, { useMemo, useState } from 'react';
import { 
  X, ShoppingBag, Trash2, Plus, Minus, ArrowRight, Gift, 
  CheckCircle2, ShieldCheck, Truck, Sparkles, ChevronRight, 
  Tag, MessageSquare, StickyNote, PenLine, ScrollText
} from 'lucide-react';
import { CartItem, Product, SiteConfig } from '../types';
import { translations } from '../translations';
import { PRODUCTS } from '../constants';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onUpdateNote: (id: string, note: string) => void;
  onRemove: (id: string) => void;
  onCheckout: () => void;
  onAddToCart: (p: Product) => void;
  t: (key: keyof typeof translations.en) => string;
  config: SiteConfig;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ 
  isOpen, 
  onClose, 
  items, 
  onUpdateQuantity, 
  onUpdateNote,
  onRemove, 
  onCheckout, 
  onAddToCart,
  t,
  config
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [openItemNotes, setOpenItemNotes] = useState<Record<string, boolean>>({});

  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const FREE_SHIPPING_THRESHOLD = config.delivery?.freeThreshold || 15000;
  const STANDARD_FEE = config.delivery?.insideDhaka || 80;
  
  const progress = Math.min((subtotal / FREE_SHIPPING_THRESHOLD) * 100, 100);
  const remaining = FREE_SHIPPING_THRESHOLD - subtotal;
  const shipping = subtotal > FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_FEE;
  const total = subtotal + shipping;

  const suggestions = useMemo(() => {
    const itemIds = new Set(items.map(i => i.id));
    return PRODUCTS.filter(p => !itemIds.has(p.id)).slice(0, 3);
  }, [items]);

  const toggleItemNote = (id: string) => {
    setOpenItemNotes(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className={`fixed inset-0 z-[300] transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      {/* Darkened Overlay */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      {/* Drawer Container - Dark Glassmorphism */}
      <div className={`absolute top-0 right-0 w-full max-w-[600px] h-full bg-[#050505]/95 backdrop-blur-2xl border-l border-[#F4EBD0]/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] transition-transform duration-500 transform ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full text-white">
          
          {/* Header */}
          <div className="p-8 border-b border-[#F4EBD0]/10 flex items-center justify-between bg-[#050505]/50 backdrop-blur-md sticky top-0 z-20">
            <div className="flex items-center gap-5">
              <div className="bg-[#2D0B1E] text-[#F4EBD0] p-3 rounded-full border border-[#F4EBD0]/20">
                <ShoppingBag size={20} strokeWidth={1.5} />
              </div>
              <div>
                <h2 className="text-3xl font-medium text-white serif tracking-wide">{t('your_box')}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[9px] uppercase tracking-[0.25em] font-medium text-[#F4EBD0]/60">
                    {items.length} {t('items_selected')}
                  </span>
                </div>
              </div>
            </div>
            <button 
              onClick={onClose} 
              className="p-3 hover:bg-white/5 rounded-full transition-all text-zinc-500 hover:text-white hover:rotate-90 duration-300"
            >
              <X size={24} strokeWidth={1} />
            </button>
          </div>

          {/* Shipping Progress */}
          {items.length > 0 && (
            <div className="px-8 py-6 border-b border-[#F4EBD0]/5 bg-[#0A0A0A]">
               <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-1.5 rounded-full ${progress >= 100 ? 'bg-[#F4EBD0] text-[#2D0B1E]' : 'bg-[#F4EBD0]/10 text-[#F4EBD0]'}`}>
                      <Truck size={14} />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-zinc-300">
                      {progress >= 100 
                        ? t('free_shipping_unlocked') 
                        : t('free_shipping_goal').replace('{amount}', remaining.toLocaleString())
                      }
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-[#F4EBD0]">{Math.round(progress)}%</span>
               </div>
               <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ease-out rounded-full ${progress >= 100 ? 'bg-[#F4EBD0] shadow-[0_0_10px_#F4EBD0]' : 'bg-[#5b2b4d]'}`}
                    style={{ width: `${progress}%` }}
                  />
               </div>
            </div>
          )}

          {/* Cart Items Area */}
          <div className="flex-1 overflow-y-auto p-8 space-y-12 custom-scrollbar">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in duration-700">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full border border-[#F4EBD0]/10 flex items-center justify-center bg-[#F4EBD0]/5">
                    <Gift size={48} strokeWidth={0.5} className="text-[#F4EBD0]" />
                  </div>
                  <Sparkles className="absolute top-0 right-0 text-[#F4EBD0] animate-pulse" size={24} />
                </div>
                <div className="max-w-xs mx-auto space-y-4">
                  <h3 className="text-2xl font-medium serif text-white">{t('box_empty')}</h3>
                  <p className="text-zinc-500 text-sm leading-relaxed font-light tracking-wide">
                    Your journey to the perfect unboxing starts here. Browse our artisan-made treasures.
                  </p>
                  <button 
                    onClick={onClose} 
                    className="mt-4 inline-flex items-center gap-3 text-[#F4EBD0] text-[10px] font-bold uppercase tracking-[0.25em] hover:text-white transition-colors group"
                  >
                    {t('start_shopping')} <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-10">
                {items.map((item) => (
                  <div key={item.id} className="flex flex-col gap-5 animate-in slide-in-from-right-10 duration-500 border-b border-[#F4EBD0]/5 pb-10 last:border-0 last:pb-0">
                    <div className="flex gap-6 group">
                      {/* Thumbnail */}
                      <div className="relative w-28 h-36 shrink-0 overflow-hidden rounded-sm border border-[#F4EBD0]/10 bg-[#111]">
                        <img 
                          src={item.image || FALLBACK_IMAGE} 
                          onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-90 group-hover:opacity-100" 
                          alt={item.name} 
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0 flex flex-col justify-between py-1">
                        <div>
                          <div className="flex justify-between items-start">
                             <div>
                               <span className="text-[8px] font-bold uppercase tracking-[0.25em] text-[#F4EBD0]/70 mb-2 block">{item.category}</span>
                               <h4 className="font-medium text-white text-lg serif leading-tight cursor-pointer hover:text-[#F4EBD0] transition-colors">{item.name}</h4>
                             </div>
                             <button 
                              onClick={() => onRemove(item.id)} 
                              className="text-zinc-600 hover:text-rose-500 transition-colors p-1"
                              title={t('remove_item')}
                            >
                              <Trash2 size={16} strokeWidth={1.5} />
                            </button>
                          </div>
                          <div className="mt-2 text-[#F4EBD0] font-medium text-base">
                             ৳{(item.price * item.quantity).toLocaleString()}
                             {item.quantity > 1 && <span className="text-zinc-600 text-xs ml-2 font-light">(৳{item.price} each)</span>}
                          </div>
                        </div>

                        {/* Controls */}
                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center bg-[#F4EBD0]/5 rounded-full border border-[#F4EBD0]/10">
                            <button 
                              onClick={() => onUpdateQuantity(item.id, -1)} 
                              className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white transition-colors hover:bg-white/5 rounded-full"
                            >
                              <Minus size={12} />
                            </button>
                            <span className="w-8 text-center text-xs font-bold text-[#F4EBD0]">{item.quantity}</span>
                            <button 
                              onClick={() => onUpdateQuantity(item.id, 1)} 
                              className="w-8 h-8 flex items-center justify-center text-zinc-400 hover:text-white transition-colors hover:bg-white/5 rounded-full"
                            >
                              <Plus size={12} />
                            </button>
                          </div>
                          
                          <button 
                            onClick={() => toggleItemNote(item.id)}
                            className={`text-[9px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors ${openItemNotes[item.id] || item.note ? 'text-[#F4EBD0]' : 'text-zinc-600 hover:text-zinc-400'}`}
                          >
                            <StickyNote size={12} /> {item.note ? 'Edit Note' : t('add_item_note')}
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    {/* Note Field - Now Fully Functional */}
                    {(openItemNotes[item.id] || item.note) && (
                        <div className="animate-in slide-in-from-top-2 duration-300">
                           <textarea 
                             value={item.note || ''}
                             onChange={(e) => onUpdateNote(item.id, e.target.value)}
                             placeholder={t('item_note_placeholder')}
                             className="w-full bg-[#1a1a1a] border border-[#F4EBD0]/10 rounded-sm p-4 text-xs text-zinc-300 focus:outline-none focus:border-[#F4EBD0]/30 transition-all resize-none h-20 placeholder-zinc-700 font-light"
                           />
                        </div>
                      )}
                  </div>
                ))}

                {/* Ritual Info */}
                <div className="bg-[#F4EBD0]/5 border border-[#F4EBD0]/10 p-6 space-y-3 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity"><ScrollText size={64} /></div>
                  <div className="relative z-10">
                     <h5 className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#F4EBD0] mb-2">{t('packaging_ritual')}</h5>
                     <p className="text-[11px] text-zinc-400 leading-relaxed font-light max-w-sm">
                       {t('ritual_desc')}
                     </p>
                  </div>
                </div>

                {/* Suggestions */}
                {suggestions.length > 0 && (
                  <div className="space-y-6 pt-6 border-t border-[#F4EBD0]/5">
                    <h5 className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 text-center">{t('complete_gift')}</h5>
                    <div className="grid grid-cols-1 gap-3">
                      {suggestions.map((p) => (
                        <div key={p.id} className="flex items-center gap-4 bg-[#111] p-3 border border-white/5 hover:border-[#F4EBD0]/20 transition-all group cursor-pointer" onClick={() => onAddToCart(p)}>
                          <div className="w-12 h-12 bg-zinc-800 shrink-0 overflow-hidden">
                            <img 
                              src={p.image || FALLBACK_IMAGE} 
                              onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform" 
                              alt={p.name} 
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h6 className="text-xs font-medium text-zinc-300 group-hover:text-white transition-colors truncate">{p.name}</h6>
                            <span className="text-[10px] text-[#F4EBD0]">৳{p.price.toLocaleString()}</span>
                          </div>
                          <button className="text-[#F4EBD0] hover:bg-[#F4EBD0] hover:text-[#2D0B1E] p-2 rounded-full transition-all border border-[#F4EBD0]/20">
                            <Plus size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer Summary */}
          {items.length > 0 && (
            <div className="p-8 border-t border-[#F4EBD0]/10 bg-[#080808] z-20 shadow-[0_-20px_50px_rgba(0,0,0,0.5)]">
               
               {/* Promo Input */}
               <div className="mb-6 relative">
                 <Tag size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600" />
                 <input 
                   type="text" 
                   value={promoCode}
                   onChange={(e) => setPromoCode(e.target.value)}
                   placeholder={t('promo_code')}
                   className="w-full bg-[#111] border border-white/5 rounded-sm py-3 pl-10 pr-20 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-[#F4EBD0]/30 transition-all uppercase tracking-widest font-bold"
                 />
                 <button className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] font-bold uppercase tracking-widest text-[#F4EBD0] hover:bg-[#F4EBD0]/10 px-3 py-1.5 rounded-sm transition-all">
                   {t('apply_btn')}
                 </button>
               </div>

               <div className="space-y-3 mb-8">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500 font-medium uppercase tracking-wider">{t('subtotal')}</span>
                    <span className="text-white font-medium">৳{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500 font-medium uppercase tracking-wider">Est. Shipping</span>
                    {shipping === 0 ? (
                      <span className="text-[#F4EBD0] font-bold uppercase tracking-widest text-[10px]">{t('complimentary')}</span>
                    ) : (
                      <span className="text-white font-medium">৳{shipping.toLocaleString()}</span>
                    )}
                  </div>
                  <div className="pt-4 border-t border-white/10 flex justify-between items-end">
                    <span className="text-sm font-bold text-white serif tracking-wide">Total</span>
                    <span className="text-2xl font-medium text-[#F4EBD0] serif">৳{total.toLocaleString()}</span>
                  </div>
               </div>

               <button 
                  onClick={onCheckout}
                  className="w-full bg-[#F4EBD0] text-[#2D0B1E] py-5 rounded-sm font-bold uppercase tracking-[0.25em] text-[10px] hover:bg-white hover:shadow-[0_0_20px_rgba(244,235,208,0.3)] transition-all active:scale-[0.99] flex items-center justify-center gap-3 group"
                >
                  {t('proceed_checkout')}
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
               </button>
               
               <div className="flex justify-center items-center gap-2 mt-4 opacity-50">
                  <ShieldCheck size={12} className="text-[#F4EBD0]" />
                  <span className="text-[8px] uppercase tracking-[0.15em] text-zinc-500">{t('secure_checkout_guarantee')}</span>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
