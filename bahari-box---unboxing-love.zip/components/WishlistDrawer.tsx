
import React from 'react';
import { X, Heart, Trash2, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { translations } from '../translations';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  onRemove: (id: string) => void;
  onMoveToCart: (product: Product) => void;
  t: (key: keyof typeof translations.en) => string;
}

const WishlistDrawer: React.FC<WishlistDrawerProps> = ({ isOpen, onClose, items, onRemove, onMoveToCart, t }) => {
  return (
    <div className={`fixed inset-0 z-[300] transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className={`absolute top-0 right-0 w-full max-w-md h-full bg-white shadow-2xl transition-transform duration-500 transform ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-white sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <div className="bg-rose-500 text-white p-2 rounded-xl"><Heart size={20} fill="currentColor" /></div>
              <div>
                <h2 className="text-2xl font-bold text-slate-800 tracking-tight serif italic">Wishlist</h2>
                <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">{items.length} {t('saved_treasures')}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-full"><X size={24} className="text-slate-400" /></button>
          </div>

          <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center text-rose-200"><Heart size={40} /></div>
                <div><h3 className="text-xl font-bold text-slate-800 mb-2">{t('wishlist_empty')}</h3></div>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.id} className="flex gap-6 group relative">
                  <div className="w-24 h-24 bg-slate-50 rounded-2xl overflow-hidden border border-slate-100">
                    <img 
                      src={item.image || FALLBACK_IMAGE} 
                      onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                      className="w-full h-full object-cover" 
                      alt={item.name} 
                    />
                  </div>
                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-bold text-slate-800 text-sm truncate">{item.name}</h4>
                      <button onClick={() => onRemove(item.id)} className="text-slate-300 hover:text-rose-500"><Trash2 size={16} /></button>
                    </div>
                    <div className="mt-auto flex items-center justify-between">
                      <span className="font-bold text-[#5b2b4d]">৳{item.price.toLocaleString()}</span>
                      <button onClick={() => { onMoveToCart(item); onRemove(item.id); }} className="text-[10px] uppercase tracking-widest font-black text-[#5b2b4d] flex items-center gap-2">{t('move_to_box')} <ArrowRight size={14} /></button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WishlistDrawer;
