
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  X, ArrowRight, ChevronLeft, CreditCard, Truck, MessageSquare, 
  Gift, Sparkles, MapPin, Calendar, Lock, ChevronDown, 
  CheckCircle2, Wallet, Banknote, ShieldCheck, ShoppingBag, Smartphone,
  Search, Check
} from 'lucide-react';
import { CartItem, SiteConfig } from '../types';
import { translations } from '../translations';
import { BANGLADESH_DISTRICTS } from '../constants';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

interface CheckoutPanelProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onComplete: () => void;
  t: (key: keyof typeof translations.en) => string;
  config: SiteConfig;
}

type Step = 'details' | 'payment' | 'success';
type MFSProvider = 'bkash' | 'nagad' | 'rocket' | 'upay';

const FloatingInput = ({ label, value, onChange, type = "text", required = false, icon: Icon, ...props }: any) => {
  const [isFocused, setIsFocused] = useState(false);
  const hasValue = value && value.length > 0;

  return (
    <div className="relative group">
      <input
        type={type}
        value={value}
        onChange={onChange}
        required={required}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className={`block px-5 pb-3 pt-6 w-full text-sm font-semibold text-slate-800 bg-slate-50 border-2 rounded-2xl appearance-none focus:outline-none focus:ring-0 focus:bg-white transition-all duration-300 peer ${isFocused || hasValue ? 'border-[#5b2b4d]/20' : 'border-slate-100 hover:border-slate-200'}`}
        placeholder=" "
        {...props}
      />
      <label className={`absolute text-xs font-bold uppercase tracking-widest duration-300 transform -translate-y-3 scale-90 top-4 z-10 origin-[0] left-5 peer-focus:text-[#5b2b4d] peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-90 peer-focus:-translate-y-3 ${hasValue ? 'text-[#5b2b4d]' : 'text-slate-400'}`}>
        {label}
      </label>
      
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none transition-all duration-300">
        {hasValue ? (
          <div className="bg-emerald-500 text-white rounded-full p-0.5 animate-in zoom-in duration-300">
             <Check size={12} strokeWidth={3} />
          </div>
        ) : (
          Icon && <Icon size={18} className="text-slate-300" />
        )}
      </div>
    </div>
  );
};

const CheckoutPanel: React.FC<CheckoutPanelProps> = ({ isOpen, onClose, items, onComplete, t, config }) => {
  const [step, setStep] = useState<Step>('details');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    district: '',
    address: '',
    note: ''
  });
  
  // Custom Searchable Dropdown State
  const [districtSearch, setDistrictSearch] = useState('');
  const [isDistrictOpen, setIsDistrictOpen] = useState(false);
  const districtDropdownRef = useRef<HTMLDivElement>(null);

  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'mfs'>('cod');
  const [mfsProvider, setMfsProvider] = useState<MFSProvider>('bkash');
  const [transactionId, setTransactionId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  
  // Dynamic Shipping Logic
  const FREE_SHIPPING_THRESHOLD = config.delivery?.freeThreshold || 15000;
  const INSIDE_DHAKA_FEE = config.delivery?.insideDhaka || 80;
  const OUTSIDE_DHAKA_FEE = config.delivery?.outsideDhaka || 120;
  
  // Calculate Shipping based on District
  let shipping = INSIDE_DHAKA_FEE; // Default estimate
  if (formData.district) {
    shipping = formData.district === 'Dhaka' ? INSIDE_DHAKA_FEE : OUTSIDE_DHAKA_FEE;
  }
  
  if (subtotal > FREE_SHIPPING_THRESHOLD) {
    shipping = 0;
  }
  
  const total = subtotal + shipping;

  const MFS_NUMBERS: Record<MFSProvider, string> = {
    bkash: config.payment?.bkash || '01700-000000',
    nagad: config.payment?.nagad || '01800-000000',
    rocket: config.payment?.rocket || '01900-000000-1',
    upay: config.payment?.upay || '01600-000000'
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (districtDropdownRef.current && !districtDropdownRef.current.contains(event.target as Node)) {
        setIsDistrictOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredDistricts = useMemo(() => {
    return BANGLADESH_DISTRICTS.filter(d => 
      d.toLowerCase().includes(districtSearch.toLowerCase())
    );
  }, [districtSearch]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'details') {
      if(!formData.name || !formData.phone || !formData.district || !formData.address) return;
      setStep('payment');
    } else {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setStep('success');
      }, 2000);
    }
  };

  const handleFinalClose = () => {
    onComplete();
    setStep('details');
    setFormData({ name: '', phone: '', district: '', address: '', note: '' });
  };

  if (step === 'success') {
    return (
      <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-500">
        <div className="bg-white w-full max-w-lg rounded-[3rem] p-12 text-center shadow-2xl animate-in zoom-in slide-in-from-bottom-10 duration-700 border border-white/10">
          <div className="w-24 h-24 bg-[#5b2b4d] text-white rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce shadow-xl shadow-[#5b2b4d]/30">
            <CheckCircle2 size={40} strokeWidth={1.5} />
          </div>
          <h2 className="text-4xl font-medium text-slate-800 mb-4 serif italic">Order Confirmed!</h2>
          <p className="text-slate-500 mb-10 leading-relaxed font-light">
            Your artisanal treasures are being prepared with love. A confirmation has been sent to your phone.
          </p>
          <div className="bg-slate-50 rounded-3xl p-8 mb-10 text-left border border-slate-100">
            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 border-b border-slate-100 pb-4">
              <span>Order Number</span>
              <span className="text-slate-800">#BB-{Math.floor(100000 + Math.random() * 900000)}</span>
            </div>
             <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 border-b border-slate-100 pb-4">
              <span>Amount Paid</span>
              <span className="text-slate-800">৳{total.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-400">
              <span>Delivery To</span>
              <span className="text-[#5b2b4d]">{formData.district}</span>
            </div>
          </div>
          <button 
            onClick={handleFinalClose}
            className="w-full bg-[#5b2b4d] text-white py-5 rounded-2xl font-bold uppercase tracking-[0.2em] text-xs hover:bg-[#4a233f] transition-all shadow-xl shadow-[#5b2b4d]/20 active:scale-[0.98]"
          >
            Return to Boutique
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[400] flex items-center justify-center p-0 md:p-6 lg:p-8 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity" onClick={onClose}></div>
      
      <div className="relative bg-[#fdfaf8] w-full max-w-7xl h-full md:h-[90vh] md:max-h-[850px] md:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row animate-in zoom-in-95 slide-in-from-bottom-12 duration-500">
        
        {/* Left Side: Order Summary (Visible on Desktop) */}
        <div className="hidden lg:flex lg:w-4/12 bg-white border-r border-slate-100 p-12 flex-col relative z-10">
          <button onClick={onClose} className="flex items-center gap-2 text-slate-400 hover:text-[#5b2b4d] transition-colors mb-12 text-[10px] font-black uppercase tracking-[0.2em]">
            <ChevronLeft size={14} /> {t('back_to_cart')}
          </button>

          <div className="space-y-8 flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4">
              <div className="bg-[#5b2b4d] text-white p-3 rounded-2xl shadow-lg shadow-[#5b2b4d]/20">
                <ShoppingBag size={24} strokeWidth={1.5} />
              </div>
              <div>
                <h3 className="text-2xl font-medium text-slate-800 serif italic">Your Selection</h3>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{items.length} Curated Treasures</p>
              </div>
            </div>

            <div className="space-y-6 flex-1 overflow-y-auto custom-scrollbar pr-4 -mr-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4 items-center group">
                  <div className="w-20 h-24 bg-slate-50 rounded-xl overflow-hidden border border-slate-100 flex-shrink-0 relative">
                    <img 
                      src={item.image || FALLBACK_IMAGE} 
                      onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                      alt={item.name} 
                    />
                    <div className="absolute bottom-0 right-0 bg-[#5b2b4d] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-tl-lg">x{item.quantity}</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-slate-800 text-sm leading-tight mb-1">{item.name}</h4>
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold truncate">{item.category}</p>
                    <div className="mt-2 font-bold text-[#5b2b4d] text-sm">৳{(item.price * item.quantity).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-8 border-t border-slate-100 space-y-4 bg-white">
               <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <span>{t('subtotal')}</span>
                  <span className="text-slate-800">৳{subtotal.toLocaleString()}</span>
               </div>
               <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <span>Shipping</span>
                  {shipping === 0 ? (
                    <span className="text-[#5b2b4d] font-black uppercase tracking-widest text-[10px]">{t('complimentary')}</span>
                  ) : (
                    <span className="text-slate-800">৳{shipping.toLocaleString()}</span>
                  )}
               </div>
               <div className="flex justify-between text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <span>Luxury Wrap</span>
                  <span className="text-emerald-500 font-black">{t('complimentary')}</span>
               </div>
               
               <div className="pt-6 mt-4 border-t-2 border-dashed border-slate-100">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">Total Amount</span>
                      <span className="text-4xl font-medium text-[#5b2b4d] serif">৳{total.toLocaleString()}</span>
                    </div>
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Right Side: Forms */}
        <div className="flex-1 flex flex-col bg-[#fdfaf8] relative">
          
          {/* Progress Tracker */}
          <div className="bg-white px-8 py-6 border-b border-slate-100 sticky top-0 z-20">
             <div className="max-w-2xl mx-auto">
               <div className="flex items-center justify-between relative">
                  {/* Connecting Line */}
                  <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-100 -z-10"></div>
                  <div 
                    className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-[#5b2b4d] transition-all duration-500 -z-10"
                    style={{ width: step === 'payment' ? '100%' : '0%' }}
                  ></div>

                  {/* Step 1 */}
                  <div className="flex items-center gap-3 bg-white pr-4">
                     <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 ${step === 'details' ? 'bg-[#5b2b4d] text-white shadow-lg shadow-[#5b2b4d]/20 scale-110' : 'bg-emerald-500 text-white'}`}>
                        {step === 'details' ? '1' : <Check size={18} strokeWidth={3} />}
                     </div>
                     <div className="flex flex-col">
                        <span className={`text-[10px] font-black uppercase tracking-widest transition-colors ${step === 'details' ? 'text-[#5b2b4d]' : 'text-slate-400'}`}>{t('delivery')}</span>
                        <span className="text-[9px] font-medium text-slate-400 hidden sm:block">Shipping Details</span>
                     </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-center gap-3 bg-white pl-4">
                     <div className="flex flex-col items-end">
                        <span className={`text-[10px] font-black uppercase tracking-widest transition-colors ${step === 'payment' ? 'text-[#5b2b4d]' : 'text-slate-300'}`}>{t('payment')}</span>
                        <span className="text-[9px] font-medium text-slate-300 hidden sm:block">Secure Checkout</span>
                     </div>
                     <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 border-2 ${step === 'payment' ? 'bg-[#5b2b4d] text-white border-[#5b2b4d] shadow-lg shadow-[#5b2b4d]/20 scale-110' : 'bg-white border-slate-100 text-slate-300'}`}>
                        2
                     </div>
                  </div>
               </div>
             </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-8 lg:p-16">
            <div className="max-w-xl mx-auto w-full h-full flex flex-col">
              <form onSubmit={handleNext} className="flex-1 flex flex-col space-y-12">
                
                {step === 'details' && (
                  <div className="space-y-10 animate-in slide-in-from-right-8 duration-500">
                    <div className="space-y-2 text-center sm:text-left">
                      <h2 className="text-3xl font-medium text-slate-800 serif italic">Where should we send this?</h2>
                      <p className="text-sm text-slate-400 font-medium">We deliver to all 64 districts of Bangladesh.</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FloatingInput 
                        label={t('recipient')}
                        value={formData.name}
                        onChange={(e: any) => handleInputChange('name', e.target.value)}
                        required
                      />
                      <FloatingInput 
                        label={t('phone')}
                        type="tel"
                        value={formData.phone}
                        onChange={(e: any) => handleInputChange('phone', e.target.value)}
                        required
                        icon={Smartphone}
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                      {/* Custom Searchable District Selector */}
                      <div className="relative group" ref={districtDropdownRef}>
                        <div 
                          className={`relative cursor-pointer`}
                          onClick={() => setIsDistrictOpen(!isDistrictOpen)}
                        >
                           <FloatingInput 
                             label={t('district')}
                             value={formData.district}
                             readOnly
                             icon={ChevronDown}
                             className="cursor-pointer"
                           />
                        </div>
                        
                        {isDistrictOpen && (
                          <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-slate-100 z-50 overflow-hidden animate-in zoom-in-95 duration-200">
                             <div className="p-3 border-b border-slate-50 bg-slate-50/50 sticky top-0">
                                <div className="relative">
                                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                  <input 
                                    autoFocus
                                    type="text" 
                                    placeholder="Search District..." 
                                    value={districtSearch}
                                    onChange={(e) => setDistrictSearch(e.target.value)}
                                    className="w-full bg-white border border-slate-200 rounded-xl py-2 pl-9 pr-3 text-xs font-bold focus:outline-none focus:border-[#5b2b4d]"
                                  />
                                </div>
                             </div>
                             <div className="max-h-60 overflow-y-auto custom-scrollbar p-1">
                                {filteredDistricts.length === 0 ? (
                                   <div className="p-4 text-center text-xs text-slate-400 font-medium">No districts found</div>
                                ) : (
                                  filteredDistricts.map(dist => (
                                    <button
                                      key={dist}
                                      type="button"
                                      onClick={() => { handleInputChange('district', dist); setIsDistrictOpen(false); setDistrictSearch(''); }}
                                      className={`w-full text-left px-4 py-3 rounded-xl text-sm font-semibold transition-colors flex justify-between items-center ${formData.district === dist ? 'bg-[#5b2b4d]/5 text-[#5b2b4d]' : 'text-slate-600 hover:bg-slate-50'}`}
                                    >
                                      {dist}
                                      {formData.district === dist && <Check size={14} />}
                                    </button>
                                  ))
                                )}
                             </div>
                          </div>
                        )}
                      </div>

                      <FloatingInput 
                        label={t('address')}
                        value={formData.address}
                        onChange={(e: any) => handleInputChange('address', e.target.value)}
                        required
                        icon={MapPin}
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center gap-2 mb-2">
                        <MessageSquare size={16} className="text-[#5b2b4d]" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Handwritten Note (Optional)</span>
                      </div>
                      <textarea 
                        value={formData.note}
                        onChange={(e) => handleInputChange('note', e.target.value)}
                        placeholder="Write a message to be handwritten by our team..." 
                        rows={3}
                        className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 px-6 focus:bg-white focus:outline-none focus:border-[#5b2b4d]/20 transition-all text-sm font-medium resize-none serif italic text-slate-700 leading-relaxed placeholder-slate-300"
                      ></textarea>
                    </div>
                  </div>
                )}

                {step === 'payment' && (
                  <div className="space-y-10 animate-in slide-in-from-right-8 duration-500">
                    <div className="space-y-2 text-center sm:text-left">
                      <h2 className="text-3xl font-medium text-slate-800 serif italic">{t('payment')}</h2>
                      <p className="text-sm text-slate-400 font-medium">Safe and secure payment options.</p>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      {/* COD Option */}
                      <button 
                        type="button"
                        onClick={() => setPaymentMethod('cod')}
                        className={`flex items-center gap-6 p-6 rounded-[2rem] border-2 transition-all text-left group relative overflow-hidden ${paymentMethod === 'cod' ? 'border-[#5b2b4d] bg-white shadow-xl shadow-[#5b2b4d]/5' : 'border-slate-100 bg-white hover:border-slate-200'}`}
                      >
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${paymentMethod === 'cod' ? 'bg-[#5b2b4d] text-white scale-110 shadow-lg shadow-[#5b2b4d]/20' : 'bg-slate-50 text-slate-400'}`}>
                          <Banknote size={24} />
                        </div>
                        <div className="flex-1 z-10">
                          <h4 className={`font-bold text-sm transition-colors ${paymentMethod === 'cod' ? 'text-[#5b2b4d]' : 'text-slate-800'}`}>{t('cod')}</h4>
                          <p className="text-xs text-slate-400 mt-1 font-medium">{t('cod_desc')}</p>
                        </div>
                        {paymentMethod === 'cod' && (
                           <div className="absolute top-4 right-4 text-[#5b2b4d] animate-in zoom-in duration-300"><CheckCircle2 size={20} fill="#F4EBD0" /></div>
                        )}
                      </button>

                      {/* MFS Option */}
                      <div className={`rounded-[2rem] border-2 transition-all overflow-hidden ${paymentMethod === 'mfs' ? 'border-[#5b2b4d] bg-white shadow-xl shadow-[#5b2b4d]/5' : 'border-slate-100 bg-white'}`}>
                        <button 
                          type="button"
                          onClick={() => setPaymentMethod('mfs')}
                          className="flex items-center gap-6 p-6 w-full text-left relative"
                        >
                          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${paymentMethod === 'mfs' ? 'bg-[#5b2b4d] text-white scale-110 shadow-lg shadow-[#5b2b4d]/20' : 'bg-slate-50 text-slate-400'}`}>
                            <Smartphone size={24} />
                          </div>
                          <div className="flex-1">
                            <h4 className={`font-bold text-sm transition-colors ${paymentMethod === 'mfs' ? 'text-[#5b2b4d]' : 'text-slate-800'}`}>{t('mfs')}</h4>
                            <p className="text-xs text-slate-400 mt-1 font-medium">{t('mfs_desc')}</p>
                          </div>
                           {paymentMethod === 'mfs' && (
                             <div className="absolute top-4 right-4 text-[#5b2b4d] animate-in zoom-in duration-300"><CheckCircle2 size={20} fill="#F4EBD0" /></div>
                          )}
                        </button>

                        {paymentMethod === 'mfs' && (
                          <div className="px-6 pb-8 animate-in slide-in-from-top-4 duration-300 space-y-6">
                             <div className="h-px w-full bg-slate-100 mb-6"></div>
                             <div className="grid grid-cols-4 gap-2">
                                {(['bkash', 'nagad', 'rocket', 'upay'] as MFSProvider[]).map((p) => (
                                  <button 
                                    key={p}
                                    type="button"
                                    onClick={() => setMfsProvider(p)}
                                    className={`py-3 rounded-xl border-2 transition-all text-[9px] font-black uppercase tracking-widest ${mfsProvider === p ? 'border-[#5b2b4d] bg-[#5b2b4d] text-white' : 'border-slate-100 text-slate-400 hover:border-slate-200'}`}
                                  >
                                    {t(`mfs_provider_${p}` as any)}
                                  </button>
                                ))}
                             </div>

                             <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 flex flex-col items-center text-center">
                                <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">{t('mfs_send_instruction')}</span>
                                <span className="text-2xl font-black text-[#5b2b4d] tracking-widest select-all cursor-pointer hover:scale-105 transition-transform">{MFS_NUMBERS[mfsProvider]}</span>
                             </div>

                             <FloatingInput 
                                label={t('mfs_txn_label')}
                                value={transactionId}
                                onChange={(e: any) => setTransactionId(e.target.value)}
                                required={paymentMethod === 'mfs'}
                                placeholder="8-10 digit TrxID"
                             />
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 text-slate-300 mt-4">
                      <Lock size={12} />
                      <span className="text-[9px] font-black uppercase tracking-widest">256-Bit SSL Secured</span>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Sticky Footer Actions */}
          <div className="border-t border-slate-100 p-8 bg-white/80 backdrop-blur-xl sticky bottom-0 z-30">
             <div className="max-w-xl mx-auto flex flex-col sm:flex-row gap-4 items-center">
                {step === 'payment' && (
                  <button 
                    type="button" 
                    onClick={() => setStep('details')}
                    className="w-full sm:w-auto px-8 py-5 font-bold text-slate-400 hover:text-[#5b2b4d] transition-colors flex items-center justify-center gap-2 bg-slate-50 hover:bg-slate-100 rounded-2xl"
                  >
                    <ChevronLeft size={18} />
                  </button>
                )}
                
                <button 
                  onClick={handleNext}
                  disabled={isLoading}
                  className="w-full flex-1 bg-[#5b2b4d] text-white py-5 rounded-2xl font-bold flex items-center justify-center gap-6 hover:bg-[#4a233f] transition-all shadow-2xl shadow-[#5b2b4d]/30 disabled:opacity-70 group relative overflow-hidden active:scale-[0.98]"
                >
                   {isLoading ? (
                    <div className="flex items-center gap-3">
                       <Sparkles className="animate-spin" size={20} />
                       <span className="uppercase tracking-widest text-xs font-black">Processing...</span>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-col items-start leading-none">
                         <span className="text-[9px] uppercase tracking-widest opacity-80 mb-1">{step === 'payment' ? 'Pay Total' : 'Total Amount'}</span>
                         <span className="text-lg font-black">৳{total.toLocaleString()}</span>
                      </div>
                      <div className="h-8 w-px bg-white/20"></div>
                      <div className="flex items-center gap-2">
                        <span className="uppercase tracking-[0.2em] text-xs font-black">
                          {step === 'payment' ? t('complete_purchase') : 'Proceed'}
                        </span>
                        <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
                      </div>
                    </>
                  )}
                </button>
             </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default CheckoutPanel;
