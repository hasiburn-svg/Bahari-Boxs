
import React from 'react';
import { MessageCircle } from 'lucide-react';

const WhatsAppButton: React.FC = () => {
  // Updated phone number format for WhatsApp URL (no +, spaces, or hyphens)
  const whatsappNumber = "8801886892056"; 
  const message = encodeURIComponent("Hello Bahari Box! I'm interested in your curated gift boxes.");
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-28 right-8 bg-[#25D366] text-white p-5 rounded-full shadow-2xl hover:bg-[#128C7E] transition-all z-50 flex items-center gap-3 group border-4 border-white shadow-[0_0_20px_rgba(37,211,102,0.3)] hover:-translate-y-1 active:scale-95"
      aria-label="Contact us on WhatsApp"
    >
      <MessageCircle size={24} fill="currentColor" />
      <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 whitespace-nowrap font-bold text-sm tracking-widest uppercase">
        WhatsApp
      </span>
    </a>
  );
};

export default WhatsAppButton;
