
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  LayoutDashboard, Package, ShoppingBag, Settings, Users, 
  Search, Edit2, Trash2, DollarSign, 
  X, Save, Image as ImageIcon, CheckCircle2,
  RefreshCw, BarChart3, UserCircle,
  Sparkles, Loader2, ShieldCheck, Zap,
  ArrowUpRight, Clock, Box, Truck, ChevronRight, MapPin,
  Megaphone, Ticket, Navigation, UserCheck, Signal, Headset,
  TrendingDown, Database, Receipt, CloudUpload, Link as LinkIcon, Lock,
  AlertTriangle, Send, MoreHorizontal, Phone, Video, Crown, Mail, FileText, Download, Filter, Gift,
  Globe, Server, Activity, Bell, Shield, Key, Eye, UserPlus, HardDrive, Wifi, Palette, LayoutTemplate, ToggleLeft,
  Upload, Link, Flame, Star, Plus, Layers, Grid, Printer, Copy
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, BarChart, Bar, Cell
} from 'recharts';
import { 
  DndContext, 
  DragOverlay, 
  closestCorners, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragStartEvent,
  DragOverEvent,
  DragEndEvent,
  defaultDropAnimationSideEffects
} from '@dnd-kit/core';
import { 
  arrayMove, 
  SortableContext, 
  sortableKeyboardCoordinates, 
  verticalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import * as L from 'leaflet';

import { Product, SiteConfig, Category } from '../types';
import { AVAILABLE_ICONS, getCategoryIcon } from '../constants';
import { geminiService } from '../services/geminiService';

const TAKA_SIGN = '\u09F3';
const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

type OrderStatus = 'Processing' | 'Packaging' | 'Shipped' | 'Delivered' | 'Dispute';

interface Order {
  id: string;
  customer: string;
  total: number;
  status: OrderStatus;
  date: string;
  itemsCount?: number;
  district?: string;
  // Mock details for view
  phone?: string;
  address?: string;
  items?: { name: string; qty: number; price: number; image?: string }[];
}

interface Coupon {
  id: string;
  code: string;
  discount: number;
  maxCap: number;
  expiry: string;
  active: boolean;
}

interface Message {
  id: string;
  sender: 'user' | 'admin';
  text: string;
  time: string;
}

interface Conversation {
  id: string;
  user: string;
  avatar: string; 
  lastMessage: string;
  time: string;
  unread: number;
  status: 'online' | 'offline';
  orderId?: string;
  messages: Message[];
}

interface Customer {
  id: string;
  name: string;
  email: string;
  avatar: string;
  totalSpent: number;
  ordersCount: number;
  lastOrderDate: string;
  status: 'VIP' | 'Loyal' | 'New' | 'Dormant';
  location: string;
  joinDate: string;
}

interface AdminPanelProps {
  onClose: () => void;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  siteConfig: SiteConfig;
  setSiteConfig: React.Dispatch<React.SetStateAction<SiteConfig>>;
}

type AdminTab = 'dashboard' | 'inventory' | 'categories' | 'orders' | 'marketing' | 'logistics' | 'concierge_desk' | 'customers' | 'storefront' | 'settings';
type EditTab = 'general' | 'pricing' | 'inventory' | 'media';

// Reset Revenue Data to 0 for a fresh site
const REVENUE_30D = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  revenue: 0,
}));

const COLUMNS: { id: OrderStatus; label: string; icon: any; color: string; bg: string }[] = [
  { id: 'Processing', label: 'New Orders', icon: Clock, color: 'text-[var(--brand-plum)]', bg: 'bg-[var(--brand-plum)]/10' },
  { id: 'Packaging', label: 'In Production', icon: Box, color: 'text-amber-500', bg: 'bg-amber-500/10' },
  { id: 'Shipped', label: 'Dispatched', icon: Truck, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  { id: 'Delivered', label: 'Delivered', icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  { id: 'Dispute', label: 'Dispute/Return', icon: AlertTriangle, color: 'text-rose-500', bg: 'bg-rose-500/10' },
];

const OrderCard: React.FC<{ order: Order; isOverlay?: boolean; onViewDetails?: (order: Order) => void }> = ({ order, isOverlay = false, onViewDetails }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: order.id });

  const style = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.3 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`bg-[var(--brand-surface)] border border-white/10 rounded-2xl p-5 shadow-lg group cursor-grab active:cursor-grabbing hover:border-[var(--brand-plum)]/40 transition-all relative overflow-hidden ${isOverlay ? 'shadow-[0_20px_50px_rgba(91,43,77,0.3)] border-[var(--brand-plum)] ring-2 ring-[var(--brand-plum)]/20 rotate-2 scale-105 z-50' : ''}`}
    >
      <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="w-1.5 h-1.5 rounded-full bg-[var(--brand-plum)] animate-pulse"></div>
      </div>

      <div className="flex justify-between items-start mb-3">
        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500 font-sans">{order.id}</span>
        <div className="flex items-center gap-1.5 bg-white/5 px-2 py-1 rounded-lg">
           <MapPin size={10} className="text-zinc-600" />
           <span className="text-[9px] font-bold text-zinc-400 font-sans">{order.district || 'Dhaka'}</span>
        </div>
      </div>
      
      <h4 className="font-bold text-white text-base mb-1 group-hover:text-[var(--brand-plum)] transition-colors serif italic tracking-wide">{order.customer}</h4>
      
      <div className="flex items-center gap-2 mb-4 font-sans">
        <span className="text-[10px] text-zinc-600 font-medium">{order.itemsCount || 1} treasures</span>
        <span className="text-[10px] text-zinc-800">•</span>
        <span className="text-[10px] text-zinc-600 font-medium">{order.date}</span>
      </div>
      
      <div className="flex justify-between items-end border-t border-white/5 pt-4">
        <span className="text-sm font-black text-white font-sans">{TAKA_SIGN}{order.total.toLocaleString()}</span>
        <button 
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            if (onViewDetails) onViewDetails(order);
          }}
          className="text-[9px] font-black uppercase tracking-widest text-zinc-500 hover:text-white flex items-center gap-1 font-sans group/btn transition-colors"
        >
          View Details <ChevronRight size={12} className="group-hover/btn:translate-x-0.5 transition-transform" />
        </button>
      </div>
    </div>
  );
};

const KanbanColumn: React.FC<{ column: typeof COLUMNS[0]; orders: Order[]; onViewDetails: (order: Order) => void }> = ({ column, orders, onViewDetails }) => {
  return (
    <div className="flex flex-col w-80 shrink-0 bg-[var(--brand-surface)]/40 border border-white/5 rounded-[2.5rem] overflow-hidden h-full">
      <div className={`p-6 border-b border-white/5 backdrop-blur-md flex items-center justify-between ${column.bg}`}>
        <div className="flex items-center gap-3">
          <column.icon size={18} className={column.color} />
          <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-zinc-300 font-sans">{column.label}</h3>
        </div>
        <span className="bg-black/20 text-white text-[10px] font-black px-2.5 py-1 rounded-full font-sans">{orders.length}</span>
      </div>
      
      <div className="p-4 flex-1 overflow-y-auto custom-scrollbar space-y-3">
        <SortableContext items={orders.map(o => o.id)} strategy={verticalListSortingStrategy}>
          {orders.map(order => (
            <OrderCard key={order.id} order={order} onViewDetails={onViewDetails} />
          ))}
        </SortableContext>
        
        {orders.length === 0 && (
          <div className="h-40 flex flex-col items-center justify-center text-center opacity-20 border-2 border-dashed border-white/5 rounded-2xl m-2">
            <Package size={32} className="text-zinc-500 mb-2" />
            <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500 font-sans">No Orders</p>
          </div>
        )}
      </div>
    </div>
  );
};

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose, products, setProducts, categories, setCategories, orders, setOrders, siteConfig, setSiteConfig }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [activeEditTab, setActiveEditTab] = useState<EditTab>('general');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [viewOrder, setViewOrder] = useState<Order | null>(null);
  const [urlInput, setUrlInput] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isInsightLoading, setIsInsightLoading] = useState(false);

  const [previewImage, setPreviewImage] = useState('');
  const [gallery, setGallery] = useState<string[]>([]);
  const [galleryUrl, setGalleryUrl] = useState('');
  const [imageTab, setImageTab] = useState<'url' | 'file'>('url');
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [isHot, setIsHot] = useState(false);
  const [isNew, setIsNew] = useState(false);
  const [descriptionInput, setDescriptionInput] = useState('');
  const [isGeneratingDesc, setIsGeneratingDesc] = useState(false);
  
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Gift');

  const nameRef = useRef<HTMLInputElement>(null);
  const categoryRef = useRef<HTMLSelectElement>(null);

  const [cmsConfig, setCmsConfig] = useState<SiteConfig>(siteConfig);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  // Marketing State - Reset to Empty
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [newCoupon, setNewCoupon] = useState({ code: '', discount: '', maxCap: '', expiry: '' });
  const [pushMessage, setPushMessage] = useState('');

  // Patrons (Customers) State - Reset to Empty
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerSearch, setCustomerSearch] = useState('');

  // Concierge State - Reset to Empty
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  const logisticsMapRef = useRef<HTMLDivElement>(null);
  const logisticsMapInstanceRef = useRef<L.Map | null>(null);

  const activeConversation = conversations.find(c => c.id === selectedChatId);

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => 
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) || 
      c.email.toLowerCase().includes(customerSearch.toLowerCase())
    );
  }, [customers, customerSearch]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    if (editingProduct) {
      setPreviewImage(editingProduct.image);
      setUrlInput(editingProduct.image);
      setIsHot(editingProduct.isHot || false);
      setIsNew(editingProduct.isNew || false);
      setDescriptionInput(editingProduct.description || '');
      setGallery(editingProduct.gallery || []);
    } else {
      setPreviewImage('');
      setUrlInput('');
      setIsHot(false);
      setIsNew(true);
      setDescriptionInput('');
      setGallery([]);
    }
  }, [editingProduct, isAddingProduct]);

  useEffect(() => {
    if (activeTab === 'concierge_desk') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeConversation?.messages, activeTab]);

  useEffect(() => {
    if (activeTab === 'dashboard' && mapRef.current && !mapInstanceRef.current) {
       const map = L.map(mapRef.current, {
          center: [23.6850, 90.3563], 
          zoom: 6,
          zoomControl: false,
          attributionControl: false,
          scrollWheelZoom: false,
          dragging: false,
          doubleClickZoom: false
       });
       L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { subdomains: 'abcd', maxZoom: 19 }).addTo(map);
       const locs = [[23.8103, 90.4125], [22.3569, 91.7832], [24.3636, 88.6241], [24.8949, 91.8687]];
       locs.forEach(loc => {
          const icon = L.divIcon({ className: 'bg-transparent', html: `<div class="w-3 h-3 bg-emerald-500 rounded-full animate-ping opacity-75"></div>`, iconSize: [12, 12] });
          L.marker(loc as L.LatLngExpression, { icon }).addTo(map);
           const staticIcon = L.divIcon({ className: 'bg-transparent', html: `<div class="w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_10px_#34d399]"></div>`, iconSize: [6, 6] });
          L.marker(loc as L.LatLngExpression, { icon: staticIcon }).addTo(map);
       });
       mapInstanceRef.current = map;
    }
    return () => {
       if (activeTab !== 'dashboard' && mapInstanceRef.current) {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
       }
    };
  }, [activeTab]);

  useEffect(() => {
    if (activeTab === 'logistics' && logisticsMapRef.current && !logisticsMapInstanceRef.current) {
       const map = L.map(logisticsMapRef.current, {
          center: [23.8103, 90.4125], // Focused on Dhaka
          zoom: 11,
          zoomControl: false,
          attributionControl: false
       });
       L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { subdomains: 'abcd', maxZoom: 19 }).addTo(map);
       
       // No active fleets for fresh site
       logisticsMapInstanceRef.current = map;
    }
    return () => {
       if (activeTab !== 'logistics' && logisticsMapInstanceRef.current) {
          logisticsMapInstanceRef.current.remove();
          logisticsMapInstanceRef.current = null;
       }
    };
  }, [activeTab]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticating(true);
    setTimeout(() => {
      if (passcode === 'popcorn') {
        setIsAuthenticated(true);
      } else {
        setPasscode('');
      }
      setIsAuthenticating(false);
    }, 1000);
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const order = orders.find(o => o.id === active.id);
    if (order) setActiveOrder(order);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) return;
    const activeId = active.id;
    const overId = over.id;
    if (activeId === overId) return;

    const isOverAColumn = COLUMNS.some(c => c.id === overId);
    if (isOverAColumn) {
      const newStatus = overId as OrderStatus;
      setOrders(prev => prev.map(o => o.id === activeId ? { ...o, status: newStatus } : o));
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = orders.findIndex(o => o.id === active.id);
      const newIndex = orders.findIndex(o => o.id === over.id);
      if (newIndex !== -1) {
        setOrders(prev => arrayMove(prev, oldIndex, newIndex));
      }
    }
    setActiveOrder(null);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleAutoGenerateDesc = async () => {
    const name = nameRef.current?.value;
    const category = categoryRef.current?.value;
    if (!name || !category) return;
    
    setIsGeneratingDesc(true);
    try {
        const desc = await geminiService.generateProductDescription(name, category);
        if (desc) setDescriptionInput(desc);
    } catch (e) {
        console.error(e);
        showToast('AI Generation Failed. Please try again.', 'error');
    } finally {
        setIsGeneratingDesc(false);
    }
  };

  const handleAddGalleryUrl = () => {
    if (galleryUrl) {
      setGallery([...gallery, galleryUrl]);
      setGalleryUrl('');
    }
  };

  const handleGalleryFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await fileToBase64(file);
      setGallery([...gallery, base64]);
    }
  };

  const removeGalleryImage = (index: number) => {
    setGallery(gallery.filter((_, i) => i !== index));
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    
    const newCategory: Category = {
      id: `cat${Date.now()}`,
      name: newCategoryName,
      icon: selectedIcon,
      count: 0
    };
    
    setCategories([...categories, newCategory]);
    setNewCategoryName('');
    showToast('Class initialized successfully.', 'success');
  };

  const handleDeleteCategory = (id: string) => {
    setCategories(categories.filter(c => c.id !== id));
    showToast('Class decommissioned.', 'success');
  };

  const handleSaveProduct = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const p: Product = {
      id: editingProduct?.id || `p${Date.now()}`,
      name: formData.get('name') as string,
      category: formData.get('category') as string,
      price: Number(formData.get('price')),
      image: previewImage || editingProduct?.image || FALLBACK_IMAGE,
      stock: Number(formData.get('stock')),
      rating: editingProduct?.rating || 5.0, 
      reviews: editingProduct?.reviews || 0, 
      sold: editingProduct?.sold || 0,
      isNew: isNew,
      isHot: isHot,
      description: descriptionInput,
      gallery: gallery, 
    };

    if (editingProduct) {
      setProducts(prev => prev.map(item => item.id === editingProduct.id ? { ...item, ...p } : item));
      showToast('Registry entry successfully updated.', 'success');
    } else {
      setProducts(prev => [p, ...prev]);
      showToast('New asset initialized in registry.', 'success');
    }
    
    setEditingProduct(null);
    setIsAddingProduct(false);
  };

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleDeleteClick = (product: Product) => {
    setProductToDelete(product);
    setDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!productToDelete) return;
    setIsDeleting(true);
    try {
        await new Promise(resolve => setTimeout(resolve, 800)); 
        setProducts(prev => prev.filter(p => p.id !== productToDelete.id));
        showToast('Asset successfully revoked from registry.', 'success');
        setDeleteModalOpen(false);
        setProductToDelete(null);
    } catch (error) {
        showToast('Failed to revoke asset. Protocol error.', 'error');
    } finally {
        setIsDeleting(false);
    }
  };

  const handleCreateCoupon = () => {
    if (!newCoupon.code || !newCoupon.discount) return;
    const coupon: Coupon = {
      id: `c${Date.now()}`,
      code: newCoupon.code.toUpperCase(),
      discount: Number(newCoupon.discount),
      maxCap: Number(newCoupon.maxCap) || 100,
      expiry: newCoupon.expiry || '2025-12-31',
      active: true
    };
    setCoupons([coupon, ...coupons]);
    setNewCoupon({ code: '', discount: '', maxCap: '', expiry: '' });
    showToast('Promotional construct initialized.', 'success');
  };

  const handleToggleCoupon = (id: string) => {
    setCoupons(prev => prev.map(c => c.id === id ? { ...c, active: !c.active } : c));
  };

  const handleSendNotification = () => {
    if (!pushMessage) return;
    showToast(`Signal Broadcasted: ${pushMessage}`, 'success');
    setPushMessage('');
  };

  const handleImageFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await fileToBase64(file);
      setPreviewImage(base64);
      setImageTab('file');
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const base64 = await fileToBase64(file);
      setPreviewImage(base64);
      setImageTab('file');
    }
  };

  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPreviewImage(e.target.value);
  };

  const handleSendMessage = () => {
    if (!chatInput.trim() || !selectedChatId) return;
    const newMessage: Message = {
      id: `m${Date.now()}`,
      sender: 'admin',
      text: chatInput,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setConversations(prev => prev.map(c => {
      if (c.id === selectedChatId) {
        return {
          ...c,
          messages: [...c.messages, newMessage],
          lastMessage: chatInput,
          time: 'Just now'
        };
      }
      return c;
    }));
    setChatInput('');
  };

  const handleQuickAction = (text: string) => {
    setChatInput(text);
  };

  const handleCmsUpdate = () => {
    setSiteConfig(cmsConfig);
    showToast('System Configuration Synchronized Successfully!', 'success');
  };

  const filteredProducts = useMemo(() => {
    return products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery, products]);

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-[1000] bg-black flex items-center justify-center p-6 animate-in fade-in duration-700 font-sans text-white">
        <div className="relative w-full max-w-lg bg-[var(--brand-surface)] border border-white/10 rounded-[4rem] p-16 shadow-[0_50px_150px_-30px_rgba(91,43,77,0.4)] text-center space-y-12 animate-in zoom-in-95 duration-1000">
          <div className="space-y-4">
             <div className="w-24 h-24 bg-[var(--brand-plum)] rounded-[2rem] flex items-center justify-center mx-auto shadow-2xl ring-2 ring-[var(--brand-plum)]/20">
                <ShieldCheck size={48} className="text-white" />
             </div>
             <h2 className="text-3xl font-bold text-white tracking-tighter logo-font">Bahari Box</h2>
             <p className="text-zinc-500 text-[11px] font-bold uppercase tracking-[0.4em] font-sans">Curator Clearance</p>
          </div>
          <form onSubmit={handleAuth} className="space-y-8">
            <input required autoFocus type="password" placeholder="Master Key" value={passcode} onChange={(e) => setPasscode(e.target.value)}
              className="w-full bg-black border-2 border-white/5 rounded-3xl py-6 px-12 focus:border-[var(--brand-plum)]/30 outline-none font-black text-white text-2xl text-center tracking-[0.4em] font-sans" />
            <button type="submit" disabled={isAuthenticating} className="w-full bg-[var(--brand-plum)] text-white py-6 rounded-3xl font-black uppercase tracking-widest text-xs hover:opacity-90 transition-all active:scale-95 font-sans">
              {isAuthenticating ? <Loader2 size={24} className="animate-spin mx-auto" /> : 'Authorize Uplink'}
            </button>
          </form>
          <button onClick={onClose} className="text-[10px] font-bold text-zinc-500 hover:text-rose-400 transition-colors uppercase tracking-widest font-sans">Abort</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[1000] bg-[var(--brand-noir)] flex animate-in fade-in duration-700 overflow-hidden font-sans text-white">
      <aside className="w-80 bg-[#000000] border-r border-white/5 text-white flex flex-col p-10 shrink-0">
        <div className="flex items-center gap-4 mb-20">
          <div className="bg-[var(--brand-plum)] p-3 rounded-2xl shadow-lg border border-white/10 ring-1 ring-[var(--brand-plum)]/20">
            <ShoppingBag size={28} className="text-white" />
          </div>
          <div>
            <span className="text-xl font-bold tracking-tight block leading-none logo-font text-[var(--brand-plum)]">Bahari Box</span>
            <span className="text-[9px] uppercase tracking-[0.5em] font-bold text-zinc-600 mt-2 block font-sans">Authenticated</span>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Analytics' },
            { id: 'inventory', icon: Package, label: 'Inventory' },
            { id: 'categories', icon: Layers, label: 'Categories' },
            { id: 'orders', icon: ShoppingBag, label: 'Command Center' },
            { id: 'marketing', icon: Megaphone, label: 'Marketing Ops' },
            { id: 'logistics', icon: Navigation, label: 'Logistics' },
            { id: 'storefront', icon: LayoutTemplate, label: 'Storefront CMS' },
            { id: 'concierge_desk', icon: Headset, label: 'Concierge Desk' },
            { id: 'customers', icon: Users, label: 'Patrons' },
            { id: 'settings', icon: Settings, label: 'System' },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`w-full flex items-center justify-between px-6 py-4 rounded-2xl font-bold text-sm transition-all duration-300 group font-sans border ${activeTab === tab.id ? 'bg-white/5 text-white border-white/20 shadow-[0_0_20px_rgba(255,255,255,0.05)]' : 'border-transparent text-zinc-600 hover:text-white hover:bg-white/5 hover:border-white/5'}`}>
              <div className="flex items-center gap-4">
                <tab.icon size={18} className={`transition-colors duration-300 ${activeTab === tab.id ? 'text-white' : 'text-zinc-600 group-hover:text-white'}`} />
                {tab.label}
              </div>
              {activeTab === tab.id && <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_10px_white]"></div>}
            </button>
          ))}
        </nav>
        <button onClick={() => setIsAuthenticated(false)} className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-sm text-zinc-500 hover:text-rose-400 transition-all mt-8 border-t border-white/5 pt-8 font-sans">
          <Lock size={18} /> Lock Registry
        </button>
      </aside>

      <main className="flex-1 flex flex-col bg-[var(--brand-noir)] overflow-hidden relative">
        <header className="px-12 pt-14 pb-10 flex justify-between items-end border-b border-white/5 bg-[var(--brand-noir)]/60 backdrop-blur-xl z-20">
          <div>
            <h1 className="text-5xl font-bold text-white tracking-tighter serif italic drop-shadow-lg">
              {activeTab === 'orders' ? 'Order Command Center' : activeTab === 'marketing' ? 'Marketing Ops' : activeTab === 'concierge_desk' ? 'Concierge Desk' : activeTab === 'customers' ? 'Patron Registry' : activeTab === 'logistics' ? 'Logistics Grid' : activeTab === 'settings' ? 'System Core' : activeTab === 'storefront' ? 'Storefront CMS' : activeTab === 'categories' ? 'Taxonomy Registry' : activeTab.charAt(0).toUpperCase() + activeTab.slice(1).replace('_', ' ') + ' Registry'}
            </h1>
            <p className="text-zinc-500 mt-5 font-bold tracking-widest uppercase text-[10px] flex items-center gap-3 font-sans">
               <ShieldCheck size={14} className="text-[var(--brand-plum)]" /> Secure Matrix Synchronized
            </p>
          </div>
          <div className="flex gap-4">
             <button className="bg-white/5 text-zinc-400 p-4 rounded-2xl hover:bg-white/10 transition-all border border-white/5 font-sans" onClick={() => setIsInsightLoading(true)}>
                <RefreshCw size={20} className={isInsightLoading ? 'animate-spin' : ''} />
             </button>
          </div>
        </header>

        <div className="px-12 py-12 flex-1 overflow-y-auto custom-scrollbar">
          {activeTab === 'dashboard' && (
            <div className="max-w-7xl space-y-8 animate-in fade-in duration-1000">
              <div className="bg-[var(--brand-surface)] border border-amber-500/20 rounded-[3rem] p-10 shadow-2xl relative overflow-hidden group">
                 <div className="flex justify-between items-end mb-8">
                    <div>
                      <h3 className="text-amber-500 font-black uppercase tracking-[0.3em] text-xs mb-2">Revenue Velocity</h3>
                      <div className="flex items-baseline gap-4">
                        <span className="text-5xl font-black text-white font-sans">{TAKA_SIGN}{(REVENUE_30D.reduce((acc, d) => acc + d.revenue, 0)).toLocaleString()}</span>
                        <div className="flex items-center text-emerald-500 text-xs font-bold font-sans bg-emerald-500/10 px-3 py-1 rounded-full">
                          <ArrowUpRight size={14} className="mr-1" /> +0.0%
                        </div>
                      </div>
                    </div>
                 </div>
                 
                 <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={REVENUE_30D}>
                        <defs>
                          <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                        <XAxis dataKey="day" stroke="#ffffff20" tick={{fill: '#52525b', fontSize: 10, fontWeight: 700}} tickLine={false} axisLine={false} dy={10} />
                        <YAxis stroke="#ffffff20" tick={{fill: '#52525b', fontSize: 10, fontWeight: 700}} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} dx={-10} />
                        <Tooltip 
                           contentStyle={{backgroundColor: '#18181b', border: '1px solid #ffffff10', borderRadius: '16px', padding: '12px'}} 
                           itemStyle={{color: '#f59e0b', fontSize: '12px', fontWeight: 'bold'}}
                           labelStyle={{color: '#71717a', fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.1em'}}
                           cursor={{stroke: '#f59e0b', strokeWidth: 1, strokeDasharray: '4 4'}}
                        />
                        <Area type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={3} fill="url(#goldGradient)" animationDuration={1500} />
                      </AreaChart>
                    </ResponsiveContainer>
                 </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl flex flex-col">
                   <h3 className="text-zinc-500 font-black uppercase tracking-[0.3em] text-xs mb-8">Top Performing Assets</h3>
                   <div className="flex-1 min-h-[300px]">
                     <ResponsiveContainer width="100%" height="100%">
                       <BarChart layout="vertical" data={products.sort((a,b) => b.sold - a.sold).slice(0,5)} margin={{ left: 0, right: 30, top: 0, bottom: 0 }}>
                          <XAxis type="number" hide />
                          <YAxis dataKey="name" type="category" width={140} tick={{fill: '#e4e4e7', fontSize: 11, fontWeight: 600}} tickLine={false} axisLine={false} />
                          <Tooltip 
                             cursor={{fill: '#ffffff05'}} 
                             contentStyle={{backgroundColor: '#18181b', border: '1px solid #ffffff10', borderRadius: '12px'}}
                             itemStyle={{color: '#fff'}}
                          />
                          <Bar dataKey="sold" radius={[0, 6, 6, 0]} barSize={24}>
                             {products.slice(0,5).map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={index === 0 ? '#f59e0b' : '#5b2b4d'} />
                             ))}
                          </Bar>
                       </BarChart>
                     </ResponsiveContainer>
                   </div>
                </div>

                <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] shadow-2xl relative overflow-hidden h-[400px] flex flex-col group">
                   <div className="absolute top-8 left-8 z-[500] pointer-events-none">
                      <h3 className="text-zinc-500 font-black uppercase tracking-[0.3em] text-xs mb-2">Live Grid</h3>
                      <div className="flex items-baseline gap-3">
                         <span className="text-5xl font-black text-white tracking-tighter">0</span>
                         <div className="flex items-center gap-2 bg-zinc-500/10 px-3 py-1.5 rounded-full border border-zinc-500/20">
                            <div className="w-2 h-2 rounded-full bg-zinc-500"></div>
                            <span className="text-[9px] text-zinc-500 font-black uppercase tracking-widest">Idle</span>
                         </div>
                      </div>
                   </div>
                   <div ref={mapRef} className="w-full h-full opacity-60 mix-blend-screen transition-opacity duration-700 group-hover:opacity-80"></div>
                   <div className="absolute inset-0 bg-gradient-to-t from-[var(--brand-surface)] via-transparent to-transparent pointer-events-none"></div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'inventory' && (
             <div className="max-w-7xl animate-in fade-in duration-700">
                <div className="flex justify-between items-center mb-12">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                    <input 
                      type="text" 
                      placeholder="Search Assets..." 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-[var(--brand-surface)] border border-white/10 rounded-2xl py-3 pl-12 pr-6 text-sm text-white focus:outline-none focus:border-[var(--brand-plum)] w-80"
                    />
                  </div>
                  <button onClick={() => { setEditingProduct(null); setIsAddingProduct(true); }} className="bg-[var(--brand-plum)] text-white px-8 py-3 rounded-2xl font-bold uppercase tracking-widest text-xs hover:opacity-90 transition-all flex items-center gap-2">
                    <Package size={16} /> Add Asset
                  </button>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {filteredProducts.map(product => (
                    <div key={product.id} className="bg-[var(--brand-surface)] border border-white/5 rounded-[2rem] p-6 shadow-xl group hover:border-[var(--brand-plum)]/30 transition-all">
                       <div className="flex gap-6">
                          <div className="w-24 h-32 bg-black rounded-xl overflow-hidden relative">
                             <img 
                               src={product.image || FALLBACK_IMAGE} 
                               onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                               className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-700" 
                               alt={product.name} 
                            />
                          </div>
                          <div className="flex-1 min-w-0 flex flex-col justify-between py-1">
                             <div>
                                <h4 className="font-bold text-white text-lg leading-tight mb-1 truncate">{product.name}</h4>
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{product.category}</span>
                             </div>
                             <div>
                                <div className="text-xl font-bold text-white mb-2">{TAKA_SIGN}{product.price.toLocaleString()}</div>
                                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${product.stock < 10 ? 'bg-rose-500/10 text-rose-500' : 'bg-emerald-500/10 text-emerald-500'}`}>
                                   <div className={`w-1.5 h-1.5 rounded-full ${product.stock < 10 ? 'bg-rose-500' : 'bg-emerald-500'}`}></div>
                                   {product.stock} Units
                                </div>
                             </div>
                          </div>
                       </div>
                       <div className="mt-6 pt-6 border-t border-white/5 flex items-center gap-3">
                          <button 
                            onClick={() => setEditingProduct(product)} 
                            className="flex-1 h-12 rounded-full border border-white/10 hover:border-white bg-white/5 hover:bg-white text-white hover:text-black font-black text-[10px] uppercase tracking-[0.2em] transition-all duration-300 flex items-center justify-center gap-3 group"
                          >
                             <Edit2 size={14} className="group-hover:-translate-y-0.5 transition-transform" /> 
                             <span>Edit Asset</span>
                          </button>
                          <button 
                            className="h-12 w-12 rounded-full border border-white/5 hover:border-rose-500 bg-white/5 hover:bg-rose-500 text-zinc-500 hover:text-white transition-all duration-300 flex items-center justify-center group"
                            onClick={() => handleDeleteClick(product)}
                          >
                             <Trash2 size={16} className="group-hover:rotate-12 transition-transform" />
                          </button>
                       </div>
                    </div>
                 ))}
               </div>
             </div>
          )}

          {activeTab === 'categories' && (
            <div className="max-w-6xl space-y-12 animate-in fade-in duration-700">
               <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                  <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl flex flex-col">
                     <div className="flex items-center gap-4 mb-8">
                        <div className="p-3 bg-white/5 rounded-2xl text-white border border-white/10"><Plus size={20} /></div>
                        <div>
                           <h3 className="text-xl font-bold text-white serif italic">Create Class</h3>
                           <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">New Taxonomy</p>
                        </div>
                     </div>
                     
                     <div className="space-y-6 flex-1">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Class Designation</label>
                           <input 
                             value={newCategoryName}
                             onChange={(e) => setNewCategoryName(e.target.value)}
                             className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:border-[var(--brand-plum)]/50 outline-none" 
                             placeholder="e.g. Wedding Series"
                           />
                        </div>
                        
                        <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Select Sigil</label>
                           <div className="grid grid-cols-5 gap-2">
                              {AVAILABLE_ICONS.map((icon) => (
                                 <button
                                    key={icon}
                                    onClick={() => setSelectedIcon(icon)}
                                    className={`aspect-square rounded-xl flex items-center justify-center transition-all ${selectedIcon === icon ? 'bg-[var(--brand-plum)] text-white shadow-lg shadow-[var(--brand-plum)]/20 scale-110' : 'bg-white/5 text-zinc-500 hover:bg-white/10 hover:text-white'}`}
                                 >
                                    {getCategoryIcon(icon)}
                                 </button>
                              ))}
                           </div>
                        </div>
                     </div>

                     <div className="mt-8 pt-6 border-t border-white/5">
                        <button 
                           onClick={handleAddCategory}
                           className="w-full bg-[var(--brand-plum)] text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:opacity-90 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"
                        >
                           Initialize Class
                        </button>
                     </div>
                  </div>

                  <div className="lg:col-span-2 space-y-6">
                     <div className="flex items-center justify-between mb-2">
                        <h3 className="text-zinc-500 font-black uppercase tracking-[0.2em] text-xs">Active Classifications</h3>
                        <span className="bg-white/5 text-white text-[10px] font-black px-3 py-1 rounded-full">{categories.length} Total</span>
                     </div>
                     
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {categories.map((cat) => {
                           const productCount = products.filter(p => p.category === cat.name).length;
                           return (
                              <div key={cat.id} className="bg-[var(--brand-surface)] border border-white/5 rounded-[2rem] p-6 flex items-center justify-between group hover:border-[var(--brand-plum)]/30 transition-all">
                                 <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center text-[var(--brand-plum)] border border-white/5">
                                       {getCategoryIcon(cat.icon)}
                                    </div>
                                    <div>
                                       <h4 className="font-bold text-white text-sm">{cat.name}</h4>
                                       <span className="text-[10px] text-zinc-500 font-bold">{productCount} Assets Linked</span>
                                    </div>
                                 </div>
                                 <button 
                                    onClick={() => handleDeleteCategory(cat.id)}
                                    className="w-10 h-10 rounded-full bg-white/5 hover:bg-rose-500/10 text-zinc-500 hover:text-rose-500 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
                                 >
                                    <Trash2 size={16} />
                                 </button>
                              </div>
                           );
                        })}
                     </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'orders' && (
             <div className="h-full flex gap-8 overflow-x-auto pb-8 snap-x">
               <DndContext 
                 sensors={sensors} 
                 collisionDetection={closestCorners} 
                 onDragStart={handleDragStart} 
                 onDragOver={handleDragOver} 
                 onDragEnd={handleDragEnd}
                 onDragCancel={() => setActiveOrder(null)}
               >
                 {COLUMNS.map(col => (
                   <KanbanColumn 
                     key={col.id} 
                     column={col} 
                     orders={orders.filter(o => o.status === col.id)}
                     onViewDetails={setViewOrder}
                   />
                 ))}
                 <DragOverlay dropAnimation={{ sideEffects: defaultDropAnimationSideEffects({ styles: { active: { opacity: '0.5' } } }) }}>
                   {activeOrder ? <OrderCard order={activeOrder} isOverlay /> : null}
                 </DragOverlay>
               </DndContext>
             </div>
          )}

          {activeTab === 'marketing' && (
            <div className="max-w-6xl space-y-12 animate-in fade-in duration-700">
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl">
                     <div className="flex items-center gap-4 mb-8">
                        <div className="p-3 bg-white/5 rounded-2xl text-white border border-white/10"><Ticket size={20} /></div>
                        <div>
                           <h3 className="text-xl font-bold text-white serif italic">Discount Constructs</h3>
                           <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Campaign Manager</p>
                        </div>
                     </div>
                     
                     <div className="space-y-4 mb-8">
                        <div className="grid grid-cols-2 gap-4">
                           <input 
                             value={newCoupon.code}
                             onChange={(e) => setNewCoupon({...newCoupon, code: e.target.value})}
                             placeholder="Code (e.g. SUMMER20)" 
                             className="bg-black border border-white/10 rounded-xl px-4 py-3 text-xs font-bold text-white outline-none focus:border-[var(--brand-plum)]" 
                           />
                           <input 
                             type="number"
                             value={newCoupon.discount}
                             onChange={(e) => setNewCoupon({...newCoupon, discount: e.target.value})}
                             placeholder="Discount %" 
                             className="bg-black border border-white/10 rounded-xl px-4 py-3 text-xs font-bold text-white outline-none focus:border-[var(--brand-plum)]" 
                           />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <input 
                             type="date"
                             value={newCoupon.expiry}
                             onChange={(e) => setNewCoupon({...newCoupon, expiry: e.target.value})}
                             className="bg-black border border-white/10 rounded-xl px-4 py-3 text-xs font-bold text-white outline-none focus:border-[var(--brand-plum)]" 
                           />
                           <button 
                             onClick={handleCreateCoupon}
                             className="bg-[var(--brand-plum)] text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-[var(--brand-plum)]/80 transition-colors"
                           >
                             Create
                           </button>
                        </div>
                     </div>

                     <div className="space-y-3">
                        {coupons.length === 0 && <div className="text-center py-10 text-zinc-500 text-xs">No Active Campaigns</div>}
                        {coupons.map(coupon => (
                           <div key={coupon.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                              <div className="flex items-center gap-4">
                                 <div className={`p-2 rounded-lg ${coupon.active ? 'bg-emerald-500/10 text-emerald-500' : 'bg-zinc-800 text-zinc-500'}`}>
                                    <Ticket size={16} />
                                 </div>
                                 <div>
                                    <div className="font-bold text-sm text-white">{coupon.code}</div>
                                    <div className="text-[10px] text-zinc-500 font-bold">{coupon.discount}% Off • Expires {coupon.expiry}</div>
                                 </div>
                              </div>
                              <button 
                                onClick={() => handleToggleCoupon(coupon.id)}
                                className={`w-10 h-6 rounded-full p-1 transition-colors ${coupon.active ? 'bg-emerald-500' : 'bg-zinc-700'}`}
                              >
                                 <div className={`w-4 h-4 bg-white rounded-full transition-transform ${coupon.active ? 'translate-x-4' : 'translate-x-0'}`}></div>
                              </button>
                           </div>
                        ))}
                     </div>
                  </div>

                  <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl">
                     <div className="flex items-center gap-4 mb-8">
                        <div className="p-3 bg-white/5 rounded-2xl text-white border border-white/10"><Megaphone size={20} /></div>
                        <div>
                           <h3 className="text-xl font-bold text-white serif italic">Broadcast Signal</h3>
                           <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Push Notifications</p>
                        </div>
                     </div>
                     
                     <div className="bg-black/30 rounded-3xl p-6 border border-white/5 mb-6">
                        <div className="flex items-center gap-3 mb-4">
                           <div className="w-8 h-8 rounded-full bg-[var(--brand-plum)] flex items-center justify-center">
                              <Bell size={14} className="text-white" />
                           </div>
                           <span className="text-xs font-bold text-white">Bahari Box App</span>
                        </div>
                        <p className="text-zinc-400 text-sm font-medium leading-relaxed">
                           {pushMessage || "Your notification preview will appear here..."}
                        </p>
                     </div>

                     <textarea 
                        value={pushMessage}
                        onChange={(e) => setPushMessage(e.target.value)}
                        placeholder="Type your broadcast message..."
                        className="w-full h-32 bg-black border border-white/10 rounded-2xl p-4 text-sm text-white font-medium outline-none focus:border-[var(--brand-plum)] mb-6 resize-none"
                     />

                     <button 
                        onClick={handleSendNotification}
                        className="w-full bg-[var(--brand-plum)] text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:opacity-90 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"
                     >
                        <Send size={14} /> Transmit Signal
                     </button>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'logistics' && (
             <div className="h-full flex flex-col animate-in fade-in duration-700">
                <div className="flex items-center justify-between mb-8 px-2">
                   <h3 className="text-2xl font-bold text-white serif italic">Fleet Operations</h3>
                   <div className="flex gap-3">
                      <div className="flex items-center gap-2 px-4 py-2 bg-zinc-500/10 rounded-full border border-zinc-500/20">
                         <div className="w-2 h-2 rounded-full bg-zinc-500"></div>
                         <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">0 Active Riders</span>
                      </div>
                   </div>
                </div>
                
                <div className="flex-1 flex gap-8 min-h-0">
                   <div className="flex-1 bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] overflow-hidden relative shadow-2xl">
                      <div ref={logisticsMapRef} className="w-full h-full opacity-80"></div>
                      <div className="absolute inset-0 bg-gradient-to-t from-[var(--brand-surface)] via-transparent to-transparent pointer-events-none h-32 bottom-0"></div>
                   </div>
                   
                   <div className="w-80 bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-6 flex flex-col shadow-2xl">
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-6">Active Fleet</h4>
                      <div className="space-y-4 flex-1 overflow-y-auto custom-scrollbar flex flex-col items-center justify-center text-zinc-600">
                         <MapPin size={24} className="mb-2 opacity-50" />
                         <span className="text-[10px] font-bold">No Active Deliveries</span>
                      </div>
                   </div>
                </div>
             </div>
          )}

          {activeTab === 'storefront' && (
             <div className="max-w-4xl space-y-12 animate-in fade-in duration-700">
                <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl">
                   <div className="flex items-center gap-4 mb-8">
                      <div className="p-3 bg-white/5 rounded-2xl text-white border border-white/10"><LayoutTemplate size={20} /></div>
                      <div>
                         <h3 className="text-xl font-bold text-white serif italic">Storefront CMS</h3>
                         <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Content Management</p>
                      </div>
                   </div>

                   <div className="space-y-8">
                      <div className="space-y-4">
                         <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Hero Headline</label>
                         <input 
                           value={cmsConfig.content.heroTitle}
                           onChange={(e) => setCmsConfig({...cmsConfig, content: {...cmsConfig.content, heroTitle: e.target.value}})}
                           className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:border-[var(--brand-plum)]/50 outline-none" 
                         />
                      </div>
                      
                      <div className="space-y-4">
                         <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Sub-Headline (Script)</label>
                         <input 
                           value={cmsConfig.content.heroSubtitle}
                           onChange={(e) => setCmsConfig({...cmsConfig, content: {...cmsConfig.content, heroSubtitle: e.target.value}})}
                           className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:border-[var(--brand-plum)]/50 outline-none" 
                         />
                      </div>

                      <div className="space-y-4">
                         <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Hero Image URL</label>
                         <input 
                           value={cmsConfig.content.heroImage}
                           onChange={(e) => setCmsConfig({...cmsConfig, content: {...cmsConfig.content, heroImage: e.target.value}})}
                           className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-xs font-mono focus:border-[var(--brand-plum)]/50 outline-none text-zinc-400" 
                         />
                      </div>

                      <div className="grid grid-cols-2 gap-6">
                         <div className="space-y-4">
                            <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Announcement Bar</label>
                            <input 
                              value={cmsConfig.content.announcement}
                              onChange={(e) => setCmsConfig({...cmsConfig, content: {...cmsConfig.content, announcement: e.target.value}})}
                              className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-xs font-bold focus:border-[var(--brand-plum)]/50 outline-none" 
                            />
                         </div>
                         <div className="space-y-4">
                            <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Standard Delivery Fee</label>
                            <input 
                              type="number"
                              value={cmsConfig.delivery.insideDhaka}
                              onChange={(e) => setCmsConfig({...cmsConfig, delivery: {...cmsConfig.delivery, insideDhaka: Number(e.target.value)}})}
                              className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-xs font-bold focus:border-[var(--brand-plum)]/50 outline-none" 
                            />
                         </div>
                      </div>

                      <div className="pt-8 border-t border-white/5">
                         <button 
                            onClick={handleCmsUpdate}
                            className="w-full bg-[var(--brand-plum)] text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[11px] hover:opacity-90 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
                         >
                            <Save size={18} /> Update Storefront
                         </button>
                      </div>
                   </div>
                </div>
             </div>
          )}

          {activeTab === 'concierge_desk' && (
             <div className="h-full flex gap-8 animate-in fade-in duration-700">
                {/* Chat List */}
                <div className="w-80 bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] overflow-hidden flex flex-col shadow-2xl">
                   <div className="p-6 border-b border-white/5">
                      <h3 className="text-[12px] font-black uppercase tracking-widest text-zinc-400">Active Conversations</h3>
                   </div>
                   <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
                      {conversations.length === 0 && <div className="text-center py-10 text-zinc-600 text-xs">No Active Chats</div>}
                      {conversations.map(chat => (
                         <div 
                           key={chat.id}
                           onClick={() => setSelectedChatId(chat.id)}
                           className={`p-4 rounded-2xl cursor-pointer transition-all border border-transparent ${selectedChatId === chat.id ? 'bg-white/10 border-white/5 shadow-lg' : 'hover:bg-white/5'}`}
                         >
                            <div className="flex items-center justify-between mb-2">
                               <div className="flex items-center gap-3">
                                  {chat.avatar ? (
                                     <img src={chat.avatar} className="w-8 h-8 rounded-full object-cover" alt="" />
                                  ) : (
                                     <div className="w-8 h-8 rounded-full bg-[var(--brand-plum)] flex items-center justify-center text-xs font-bold">{chat.user[0]}</div>
                                  )}
                                  <span className="font-bold text-xs text-white">{chat.user.split(' ')[0]}</span>
                               </div>
                               <span className="text-[9px] font-bold text-zinc-500">{chat.time}</span>
                            </div>
                            <p className="text-[10px] text-zinc-400 font-medium truncate pl-11">{chat.lastMessage}</p>
                         </div>
                      ))}
                   </div>
                </div>

                {/* Chat Area */}
                <div className="flex-1 bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] overflow-hidden flex flex-col shadow-2xl relative">
                   {activeConversation ? (
                      <>
                         <div className="p-6 border-b border-white/5 flex items-center justify-between bg-black/20">
                            <div className="flex items-center gap-4">
                               <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
                                  <UserCircle size={20} className="text-zinc-400" />
                               </div>
                               <div>
                                  <h3 className="font-bold text-sm text-white">{activeConversation.user}</h3>
                                  <div className="flex items-center gap-2">
                                     <div className={`w-1.5 h-1.5 rounded-full ${activeConversation.status === 'online' ? 'bg-emerald-500' : 'bg-zinc-500'}`}></div>
                                     <span className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">{activeConversation.status}</span>
                                  </div>
                               </div>
                            </div>
                         </div>
                         
                         <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-6">
                            {activeConversation.messages.map(msg => (
                               <div key={msg.id} className={`flex ${msg.sender === 'admin' ? 'justify-end' : 'justify-start'}`}>
                                  <div className={`max-w-[70%] p-4 rounded-2xl text-xs font-medium leading-relaxed ${msg.sender === 'admin' ? 'bg-[var(--brand-plum)] text-white rounded-tr-sm' : 'bg-white/5 text-zinc-300 rounded-tl-sm'}`}>
                                     {msg.text}
                                  </div>
                               </div>
                            ))}
                            <div ref={chatEndRef}></div>
                         </div>

                         <div className="p-6 border-t border-white/5 bg-black/20">
                            <div className="flex gap-4">
                               <div className="flex-1 relative">
                                  <input 
                                    value={chatInput}
                                    onChange={(e) => setChatInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                                    placeholder="Type your response..."
                                    className="w-full bg-black border border-white/10 rounded-xl py-4 pl-6 pr-12 text-xs font-bold text-white focus:border-[var(--brand-plum)] outline-none"
                                  />
                                  <button onClick={handleSendMessage} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/5 hover:bg-[var(--brand-plum)] rounded-lg text-zinc-400 hover:text-white transition-all">
                                     <Send size={14} />
                                  </button>
                               </div>
                            </div>
                            <div className="flex gap-2 mt-4 overflow-x-auto pb-2 custom-scrollbar">
                               {['Thank you for your order!', 'It is on the way.', 'Can I help with anything else?'].map(reply => (
                                  <button 
                                    key={reply}
                                    onClick={() => handleQuickAction(reply)}
                                    className="whitespace-nowrap px-4 py-2 bg-white/5 rounded-full text-[9px] font-bold uppercase tracking-wider text-zinc-500 hover:text-white hover:bg-white/10 transition-all border border-white/5"
                                  >
                                     {reply}
                                  </button>
                               ))}
                            </div>
                         </div>
                      </>
                   ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-zinc-600">
                         <Headset size={48} strokeWidth={1} className="mb-4 opacity-50" />
                         <p className="text-xs font-bold uppercase tracking-widest">No Active Conversations</p>
                      </div>
                   )}
                </div>
             </div>
          )}

          {activeTab === 'customers' && (
             <div className="max-w-7xl animate-in fade-in duration-700">
                <div className="flex justify-between items-center mb-12">
                   <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                      <input 
                        type="text" 
                        placeholder="Search Patrons..." 
                        value={customerSearch}
                        onChange={(e) => setCustomerSearch(e.target.value)}
                        className="bg-[var(--brand-surface)] border border-white/10 rounded-2xl py-3 pl-12 pr-6 text-sm text-white focus:outline-none focus:border-[var(--brand-plum)] w-80"
                      />
                   </div>
                   <div className="flex items-center gap-4 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                      <span className="flex items-center gap-2"><Users size={14} /> Total Patrons: {customers.length}</span>
                   </div>
                </div>

                {customers.length === 0 ? (
                   <div className="flex flex-col items-center justify-center h-64 text-zinc-600 border-2 border-dashed border-white/5 rounded-[3rem]">
                      <Users size={48} className="mb-4 opacity-50" />
                      <p className="text-xs font-bold uppercase tracking-widest">No Patrons Registered</p>
                   </div>
                ) : (
                   <div className="grid grid-cols-1 gap-4">
                      {filteredCustomers.map(customer => (
                         <div key={customer.id} className="bg-[var(--brand-surface)] border border-white/5 rounded-3xl p-6 flex items-center justify-between group hover:border-[var(--brand-plum)]/30 transition-all">
                            {/* ... existing customer card ... */}
                         </div>
                      ))}
                   </div>
                )}
             </div>
          )}

          {activeTab === 'settings' && (
            <div className="max-w-4xl space-y-12 animate-in fade-in duration-700">
               <div className="bg-[var(--brand-surface)] border border-white/10 rounded-[3rem] p-10 shadow-2xl">
                  <div className="flex items-center gap-4 mb-8 border-b border-white/5 pb-8">
                     <div className="p-3 bg-[var(--brand-plum)] rounded-2xl text-white border border-white/10 ring-1 ring-[var(--brand-plum)]/20 shadow-lg">
                        <Settings size={24} />
                     </div>
                     <div>
                        <h3 className="text-2xl font-bold text-white serif italic">System Core</h3>
                        <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">Global Configuration</p>
                     </div>
                  </div>

                  <div className="space-y-10">
                     <div>
                        <h4 className="text-zinc-400 text-xs font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                           <DollarSign size={14} className="text-emerald-500" /> Payment Gateways (MFS)
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           {['bkash', 'nagad', 'rocket', 'upay'].map((provider) => (
                              <div key={provider} className="space-y-2">
                                 <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">
                                    {provider.charAt(0).toUpperCase() + provider.slice(1)} Number
                                 </label>
                                 <input 
                                    value={(cmsConfig.payment as any)?.[provider] || ''}
                                    onChange={(e) => setCmsConfig({
                                       ...cmsConfig,
                                       payment: { ...cmsConfig.payment, [provider]: e.target.value } as any
                                    })}
                                    className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 text-white text-sm font-bold focus:border-[var(--brand-plum)]/50 outline-none"
                                    placeholder="017XX-XXXXXX"
                                 />
                              </div>
                           ))}
                        </div>
                     </div>

                     <div className="pt-8 border-t border-white/5">
                        <button 
                           onClick={handleCmsUpdate}
                           className="w-full bg-emerald-500 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-emerald-600 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
                        >
                           <Save size={16} /> Synchronize Configuration
                        </button>
                     </div>
                  </div>
               </div>
            </div>
          )}
        </div>
      </main>

      {/* ... (Keep existing modals) ... */}
      
      {viewOrder && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-300 font-sans" onClick={() => setViewOrder(null)}>
           <div className="bg-[#0c0c0e] w-full max-w-2xl rounded-[2.5rem] border border-white/10 overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300" onClick={(e) => e.stopPropagation()}>
              <div className="p-8 border-b border-white/5 flex items-center justify-between">
                 <div>
                    <h3 className="text-2xl font-bold text-white serif italic">Order Details</h3>
                    <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mt-1">#{viewOrder.id} • {viewOrder.date}</p>
                 </div>
                 <button onClick={() => setViewOrder(null)} className="p-2 bg-white/5 rounded-full text-zinc-400 hover:text-white transition-colors">
                    <X size={20} />
                 </button>
              </div>
              
              <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                 {/* Customer Info */}
                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-1">
                       <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500">Customer</span>
                       <div className="font-bold text-white text-sm">{viewOrder.customer}</div>
                       <div className="text-xs text-zinc-400">017XX-XXXXXX</div>
                    </div>
                    <div className="space-y-1">
                       <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500">Delivery Location</span>
                       <div className="font-bold text-white text-sm">{viewOrder.address || "House 12, Road 5, Gulshan 1"}</div>
                       <div className="text-xs text-zinc-400">{viewOrder.district || "Dhaka"}</div>
                    </div>
                 </div>

                 {/* Order Items Mock */}
                 <div className="space-y-4">
                    <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500 block">Manifest</span>
                    {[1].map(i => (
                       <div key={i} className="flex items-center gap-4 bg-white/5 p-3 rounded-xl border border-white/5">
                          <div className="w-12 h-12 bg-black rounded-lg overflow-hidden">
                             <img src={FALLBACK_IMAGE} className="w-full h-full object-cover opacity-80" alt="" />
                          </div>
                          <div className="flex-1">
                             <div className="text-sm font-bold text-white">Signature Gift Box</div>
                             <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Premium Selection</div>
                          </div>
                          <div className="text-right">
                             <div className="text-sm font-bold text-white">{TAKA_SIGN}{viewOrder.total.toLocaleString()}</div>
                             <div className="text-[10px] text-zinc-500 font-bold">Qty: {viewOrder.itemsCount || 1}</div>
                          </div>
                       </div>
                    ))}
                 </div>

                 {/* Financials */}
                 <div className="bg-black/40 rounded-2xl p-6 space-y-3">
                    <div className="flex justify-between text-xs text-zinc-400">
                       <span>Subtotal</span>
                       <span>{TAKA_SIGN}{viewOrder.total.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-xs text-zinc-400">
                       <span>Shipping</span>
                       <span>{TAKA_SIGN}0</span>
                    </div>
                    <div className="pt-3 border-t border-white/10 flex justify-between text-sm font-bold text-white">
                       <span>Total Paid</span>
                       <span className="text-[var(--brand-plum)]">{TAKA_SIGN}{viewOrder.total.toLocaleString()}</span>
                    </div>
                 </div>
              </div>

              <div className="p-6 border-t border-white/5 bg-white/5 flex gap-3">
                 <button className="flex-1 py-4 rounded-xl bg-[var(--brand-plum)] text-white font-black uppercase tracking-widest text-[10px] hover:opacity-90 transition-all flex items-center justify-center gap-2">
                    <Printer size={14} /> Print Invoice
                 </button>
                 <button className="flex-1 py-4 rounded-xl bg-white/5 text-white font-black uppercase tracking-widest text-[10px] hover:bg-white/10 transition-all border border-white/10 flex items-center justify-center gap-2">
                    <Copy size={14} /> Copy Details
                 </button>
              </div>
           </div>
        </div>
      )}

      {(editingProduct || isAddingProduct) && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-6 md:p-12 animate-in fade-in duration-500 font-sans">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-3xl" onClick={() => { setEditingProduct(null); setIsAddingProduct(false); }}></div>
          <div className="relative bg-[var(--brand-surface)] w-full max-w-6xl rounded-[3rem] overflow-hidden border border-white/10 text-white shadow-2xl flex flex-col max-h-[90vh]">
            <header className="px-10 py-8 border-b border-white/5 bg-[var(--brand-noir)]/40 flex items-center justify-between shrink-0">
               <div>
                 <h3 className="text-3xl font-bold serif italic tracking-tight logo-font text-[var(--brand-plum)]">Manifest Registry Entry</h3>
                 <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Registry Entry Protocol</p>
               </div>
               <button onClick={() => { setEditingProduct(null); setIsAddingProduct(false); }} className="p-3 bg-white/5 hover:bg-rose-500/20 rounded-full transition-all text-zinc-500"><X size={20} /></button>
            </header>
            
            <form onSubmit={handleSaveProduct} className="flex-1 overflow-hidden flex flex-col lg:flex-row">
               <div className="w-full lg:w-5/12 bg-black/20 border-r border-white/5 p-10 overflow-y-auto custom-scrollbar flex flex-col gap-8">
                  <div className="space-y-4">
                     <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1 flex items-center gap-2">
                        <ImageIcon size={12} /> Asset Imagery
                     </label>
                     
                     <div className="w-full aspect-[3/4] bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative group">
                        <div className="w-full h-full relative">
                           <img 
                            src={previewImage || FALLBACK_IMAGE} 
                            onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                            className={`w-full h-full object-cover transition-all ${!previewImage ? 'opacity-30 grayscale' : ''}`} 
                            alt="Preview" 
                          />
                          {!previewImage && (
                             <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-500 gap-4 pointer-events-none">
                                <ImageIcon size={48} strokeWidth={1} className="opacity-50" />
                                <span className="text-[10px] uppercase tracking-widest font-bold opacity-50">Enter Asset URL</span>
                             </div>
                          )}
                        </div>
                        
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                           <span className="text-white text-[10px] font-black uppercase tracking-widest">Live Preview</span>
                        </div>
                     </div>

                     <div className="bg-black/40 p-1.5 rounded-xl border border-white/5 flex gap-1">
                        <button 
                           type="button"
                           onClick={() => setImageTab('url')}
                           className={`flex-1 py-3 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${imageTab === 'url' ? 'bg-[var(--brand-surface)] text-white shadow-lg border border-white/10' : 'text-zinc-500 hover:text-white'}`}
                        >
                           <Link size={12} /> Link URL
                        </button>
                        <button 
                           type="button"
                           onClick={() => setImageTab('file')}
                           className={`flex-1 py-3 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${imageTab === 'file' ? 'bg-[var(--brand-surface)] text-white shadow-lg border border-white/10' : 'text-zinc-500 hover:text-white'}`}
                        >
                           <Upload size={12} /> Upload Device
                        </button>
                     </div>

                     {imageTab === 'url' ? (
                        <div className="relative group">
                           <LinkIcon size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-[var(--brand-plum)] transition-colors" />
                           <input 
                              type="text" 
                              value={previewImage.startsWith('data:') ? '' : previewImage} 
                              onChange={handleImageUrlChange}
                              placeholder="https://..."
                              className="w-full bg-black border border-white/10 rounded-2xl py-4 pl-12 pr-6 focus:border-[var(--brand-plum)] outline-none text-xs text-white font-bold placeholder-zinc-700 transition-all" 
                           />
                        </div>
                     ) : (
                        <label 
                          onDragEnter={handleDragEnter}
                          onDragLeave={handleDragLeave}
                          onDragOver={handleDragEnter}
                          onDrop={handleDrop}
                          className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-2xl cursor-pointer transition-all group ${isDraggingFile ? 'border-[var(--brand-plum)] bg-[var(--brand-plum)]/10 scale-[1.02]' : 'border-white/10 hover:border-[var(--brand-plum)] hover:bg-[var(--brand-plum)]/5'}`}
                        >
                           <div className="flex flex-col items-center justify-center pt-5 pb-6 pointer-events-none">
                              <CloudUpload size={24} className={`mb-3 transition-colors ${isDraggingFile ? 'text-[var(--brand-plum)]' : 'text-zinc-500 group-hover:text-[var(--brand-plum)]'}`} />
                              <p className="mb-2 text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Drop or Click</p>
                           </div>
                           <input type="file" className="hidden" onChange={handleImageFileSelect} accept="image/*" />
                        </label>
                     )}
                  </div>

                  <div className="space-y-4 pt-6 border-t border-white/5">
                    <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Gallery Repertoire</label>
                    
                    <div className="grid grid-cols-4 gap-2">
                      {gallery.map((img, idx) => (
                        <div key={idx} className="relative aspect-square bg-black rounded-lg overflow-hidden border border-white/10 group">
                          <img 
                            src={img || FALLBACK_IMAGE} 
                            onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = FALLBACK_IMAGE; }}
                            className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" 
                            alt={`Gallery ${idx}`} 
                          />
                          <button 
                            type="button" 
                            onClick={() => removeGalleryImage(idx)}
                            className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-500"
                          >
                            <X size={10} />
                          </button>
                        </div>
                      ))}
                      
                      <label className="aspect-square bg-white/5 rounded-lg border border-white/5 border-dashed flex flex-col items-center justify-center cursor-pointer hover:bg-white/10 hover:border-white/20 transition-all text-zinc-500 hover:text-white group">
                         <Plus size={18} className="mb-1" />
                         <span className="text-[8px] font-bold uppercase">Add</span>
                         <input type="file" className="hidden" onChange={handleGalleryFile} accept="image/*" />
                      </label>
                    </div>

                    <div className="flex gap-2">
                       <input 
                         value={galleryUrl}
                         onChange={(e) => setGalleryUrl(e.target.value)}
                         placeholder="Add Image URL..."
                         className="flex-1 bg-black border border-white/10 rounded-xl px-3 py-2 text-[10px] text-white focus:border-[var(--brand-plum)] outline-none"
                       />
                       <button 
                         type="button"
                         onClick={handleAddGalleryUrl}
                         className="bg-white/5 hover:bg-white/10 border border-white/5 text-white px-3 rounded-xl transition-colors"
                       >
                         <Plus size={14} />
                       </button>
                    </div>
                  </div>
               </div>

               <div className="flex-1 p-10 overflow-y-auto custom-scrollbar flex flex-col gap-10">
                  <div className="space-y-6">
                     <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Asset Designation</label>
                       <input ref={nameRef} required name="name" defaultValue={editingProduct?.name} placeholder="Product Name" className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 focus:border-[var(--brand-plum)]/50 outline-none text-white text-lg font-bold placeholder-zinc-800" />
                     </div>

                     <div className="space-y-2">
                        <div className="flex justify-between items-center">
                           <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Asset Description</label>
                           <button 
                             type="button" 
                             onClick={handleAutoGenerateDesc} 
                             disabled={isGeneratingDesc}
                             className="text-[9px] font-bold uppercase tracking-widest text-[var(--brand-plum)] flex items-center gap-1 hover:text-white transition-colors disabled:opacity-50"
                           >
                             {isGeneratingDesc ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />}
                             {isGeneratingDesc ? 'Generating...' : 'Auto-Write'}
                           </button>
                        </div>
                        <textarea 
                           name="description" 
                           value={descriptionInput}
                           onChange={(e) => setDescriptionInput(e.target.value)}
                           placeholder="Detailed product narrative..."
                           className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 focus:border-[var(--brand-plum)]/50 outline-none text-white text-sm font-medium placeholder-zinc-800 min-h-[100px] resize-none leading-relaxed"
                        />
                     </div>

                     <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Category</label>
                           <div className="relative">
                              <select 
                                ref={categoryRef} 
                                name="category" 
                                defaultValue={editingProduct?.category || categories[0]?.name || "Signature Boxes"} 
                                className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 focus:border-[var(--brand-plum)]/50 outline-none text-white text-xs font-bold appearance-none cursor-pointer"
                              >
                                 {categories.map(cat => <option key={cat.id} value={cat.name}>{cat.name}</option>)}
                              </select>
                              <ChevronRight className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none rotate-90" size={14} />
                           </div>
                        </div>
                        <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Stock Count</label>
                           <input required type="number" name="stock" defaultValue={editingProduct?.stock || 0} className="w-full bg-black border border-white/10 rounded-2xl py-4 px-6 focus:border-[var(--brand-plum)]/50 outline-none text-white text-xs font-bold" />
                        </div>
                     </div>

                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 ml-1">Valuation</label>
                        <div className="relative">
                           <span className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-500 font-serif italic text-lg">{TAKA_SIGN}</span>
                           <input required type="number" name="price" defaultValue={editingProduct?.price} className="w-full bg-black border border-white/10 rounded-2xl py-4 pl-12 pr-6 focus:border-[var(--brand-plum)]/50 outline-none text-white text-xl font-bold" />
                        </div>
                     </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                     <div 
                        onClick={() => setIsHot(!isHot)}
                        className={`cursor-pointer border rounded-2xl p-4 flex items-center justify-between transition-all ${isHot ? 'bg-[var(--brand-plum)]/10 border-[var(--brand-plum)]' : 'bg-black border-white/5 hover:border-white/10'}`}
                     >
                        <div className="flex items-center gap-3">
                           <div className={`p-2 rounded-lg ${isHot ? 'bg-[var(--brand-plum)] text-white' : 'bg-white/5 text-zinc-500'}`}><Flame size={16} /></div>
                           <div>
                              <div className="text-xs font-bold text-white">Trending / Hot</div>
                              <div className="text-[9px] text-zinc-500">Badge on card</div>
                           </div>
                        </div>
                        <div className={`w-10 h-5 rounded-full relative transition-colors ${isHot ? 'bg-[var(--brand-plum)]' : 'bg-white/10'}`}>
                           <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isHot ? 'left-6' : 'left-1'}`}></div>
                        </div>
                     </div>

                     <div 
                        onClick={() => setIsNew(!isNew)}
                        className={`cursor-pointer border rounded-2xl p-4 flex items-center justify-between transition-all ${isNew ? 'bg-purple-500/10 border-purple-500' : 'bg-black border-white/5 hover:border-white/10'}`}
                     >
                        <div className="flex items-center gap-3">
                           <div className={`p-2 rounded-lg ${isNew ? 'bg-purple-500 text-white' : 'bg-white/5 text-zinc-500'}`}><Star size={16} /></div>
                           <div>
                              <div className="text-xs font-bold text-white">New Arrival</div>
                              <div className="text-[9px] text-zinc-500">Limited edition tag</div>
                           </div>
                        </div>
                        <div className={`w-10 h-5 rounded-full relative transition-colors ${isNew ? 'bg-purple-500' : 'bg-white/10'}`}>
                           <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isNew ? 'left-6' : 'left-1'}`}></div>
                        </div>
                     </div>
                  </div>

                  <div className="mt-auto pt-6 border-t border-white/5">
                     <button type="submit" className="w-full bg-[var(--brand-plum)] text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[11px] hover:opacity-90 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3">
                       <Save size={18} /> Authorize Registry Update
                     </button>
                  </div>
               </div>
            </form>
          </div>
        </div>
      )}

      {deleteModalOpen && (
        <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => !isDeleting && setDeleteModalOpen(false)}></div>
            <div className="relative bg-[#0c0c0e] border border-white/10 rounded-[2.5rem] p-10 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-300">
                <div className="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <AlertTriangle className="text-rose-500" size={32} />
                </div>
                <div className="text-center space-y-2 mb-8">
                    <h3 className="text-2xl font-bold text-white serif">Revoke Asset?</h3>
                    <p className="text-zinc-500 text-sm">
                        You are about to remove <span className="text-white font-bold">{productToDelete?.name}</span> from the registry. This action is irreversible.
                    </p>
                </div>
                <div className="flex gap-4">
                    <button 
                        onClick={() => setDeleteModalOpen(false)}
                        disabled={isDeleting}
                        className="flex-1 py-4 rounded-2xl font-bold text-xs uppercase tracking-widest text-zinc-400 hover:bg-white/5 transition-all"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={confirmDelete}
                        disabled={isDeleting}
                        className="flex-1 bg-rose-500 text-white py-4 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-rose-600 transition-all shadow-lg shadow-rose-500/20 flex items-center justify-center gap-2"
                    >
                        {isDeleting ? <Loader2 size={16} className="animate-spin" /> : 'Confirm Delete'}
                    </button>
                </div>
            </div>
        </div>
      )}

      <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[1300] bg-white text-black px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 transition-all duration-500 ${toast ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0 pointer-events-none'}`}>
          <div className={`p-1 rounded-full ${toast?.type === 'error' ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
              {toast?.type === 'error' ? <AlertTriangle size={14} /> : <CheckCircle2 size={14} />}
          </div>
          <span className="text-xs font-bold uppercase tracking-wider">{toast?.message}</span>
      </div>
    </div>
  );
};

export default AdminPanel;
