
import React, { useState, useEffect, useMemo } from 'react';
import { ShoppingBag, ArrowRight, Star, ShieldCheck, Heart, Search, Sparkles, MapPin, Feather, Play, X, Eye, Menu, Share2 } from 'lucide-react';
import { Product, SiteConfig, Category } from '../types';

const TAKA_SIGN = '\u09F3';

interface HomepageProps {
  products: Product[];
  categories: Category[];
  onOpenAdmin: () => void;
  onAddToCart: (p: Product) => void;
  // New Functional Props
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onToggleWishlist: (id: string) => void;
  wishlistIds: string[];
  onQuickView: (p: Product) => void;
  config: SiteConfig;
}

const Homepage: React.FC<HomepageProps> = ({ 
  products,
  categories,
  onOpenAdmin, 
  onAddToCart,
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onToggleWishlist,
  wishlistIds,
  onQuickView,
  config
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isRitualOpen, setIsRitualOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleShare = async (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    
    let shareUrl = window.location.href;
    try {
        // Use origin + pathname to strip existing query params/hashes for a clean share link
        const baseUrl = window.location.origin + window.location.pathname;
        const urlObj = new URL(baseUrl);
        urlObj.searchParams.set('product', product.id);
        shareUrl = urlObj.toString();
    } catch (error) {
        // Fallback: use current href as is
        shareUrl = window.location.href; 
    }

    const shareData = {
      title: `Bahari Box - ${product.name}`,
      text: `Check out ${product.name} at Bahari Box.`,
      url: shareUrl,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        throw new Error('Web Share API not supported');
      }
    } catch (err) {
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        // Optional: You could use a toast notification here instead of alert
        alert('Link copied to clipboard!'); 
      } catch (clipboardErr) {
        console.error('Clipboard failed:', clipboardErr);
      }
    }
  };

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchQuery, activeCategory]);

  return (
    <div className="bg-[var(--brand-noir)] text-white min-h-screen font-sans">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 px-6 md:px-8 py-4 md:py-6 ${isScrolled ? 'bg-[var(--brand-noir)]/90 backdrop-blur-md border-b border-[var(--brand-champagne)]/10 shadow-2xl' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Brand */}
          <div className="flex items-center gap-16">
            <div className="flex items-center gap-3 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
              <div className="relative w-8 h-8 flex items-center justify-center">
                 <ShoppingBag size={20} className="text-[var(--brand-champagne)]" strokeWidth={1} />
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-white flex flex-col leading-none">
                <span className="serif text-2xl tracking-wide text-white">BAHARI</span>
                <span className="text-[8px] uppercase tracking-[0.6em] font-medium mt-1 text-[var(--brand-champagne)]/80 ml-0.5">Box • Dhaka</span>
              </h1>
            </div>
            
            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-10">
              {[
                { label: 'Boutique', id: 'boutique' },
                { label: 'Occasions', id: 'boutique' },
                { label: 'Heritage', id: 'footer' },
                { label: 'Concierge', id: 'footer' }
              ].map((item) => (
                <button 
                  key={item.label} 
                  onClick={() => scrollToSection(item.id)}
                  className="text-[9px] uppercase tracking-[0.25em] font-medium text-zinc-400 hover:text-[var(--brand-champagne)] transition-colors relative group"
                >
                  {item.label}
                  <span className="absolute -bottom-2 left-1/2 w-0 h-px bg-[var(--brand-champagne)] transition-all duration-500 group-hover:w-full group-hover:left-0"></span>
                </button>
              ))}
            </nav>
          </div>
          
          {/* Functional Icons & Search */}
          <div className="flex items-center gap-4 md:gap-8">
            {/* Search Bar */}
            <div className="hidden md:flex items-center relative group">
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); if(e.target.value) scrollToSection('boutique'); }}
                placeholder="Search treasures..."
                className="bg-transparent border-b border-[var(--brand-champagne)]/30 py-1 pl-0 pr-8 text-xs text-[var(--brand-champagne)] placeholder-zinc-600 focus:outline-none focus:border-[var(--brand-champagne)] transition-all w-24 focus:w-48"
              />
              <Search size={14} className="absolute right-0 text-[var(--brand-champagne)]/50" />
            </div>

            <div className="flex items-center gap-4">
               {/* Wishlist */}
               <button onClick={onOpenWishlist} className="relative text-zinc-400 hover:text-[var(--brand-champagne)] transition-colors group">
                  <Heart size={20} strokeWidth={1.5} className={wishlistCount > 0 ? "fill-[var(--brand-champagne)] text-[var(--brand-champagne)]" : ""} />
                  {wishlistCount > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 bg-[var(--brand-champagne)] text-[var(--brand-noir)] text-[8px] font-black rounded-full flex items-center justify-center">
                      {wishlistCount}
                    </span>
                  )}
               </button>

               {/* Cart */}
               <button onClick={onOpenCart} className="relative text-zinc-400 hover:text-[var(--brand-champagne)] transition-colors group">
                  <ShoppingBag size={20} strokeWidth={1.5} />
                  {cartCount > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 bg-[var(--brand-plum)] text-white border border-[var(--brand-champagne)]/20 text-[8px] font-black rounded-full flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
               </button>
               
               {/* Admin Trigger */}
               <button onClick={onOpenAdmin} className="hidden md:flex text-[9px] uppercase tracking-[0.2em] font-medium text-zinc-600 hover:text-[var(--brand-champagne)] transition-colors items-center gap-2">
                 <div className="w-1 h-1 bg-[var(--brand-champagne)] rounded-full"></div>
               </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section - Dynamic Content */}
      <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
          style={{ backgroundImage: `url('${config.content.heroImage}')` }}
        >
          <div className="absolute inset-0 bg-black/60"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-[var(--brand-noir)]"></div>
        </div>
        
        <div className="relative z-10 text-center max-w-5xl px-6 flex flex-col items-center animate-in fade-in zoom-in duration-1000">
          
          <div className="mb-12 inline-flex items-center gap-3 px-5 py-2.5 border border-[var(--brand-champagne)]/20 rounded-full backdrop-blur-sm">
            <div className="w-1.5 h-1.5 bg-[var(--brand-champagne)] rounded-full animate-pulse"></div>
            <span className="text-[9px] uppercase font-bold tracking-[0.35em] text-[var(--brand-champagne)]">{config.content.announcement}</span>
          </div>

          <h2 className="text-6xl md:text-8xl lg:text-9xl font-medium tracking-tight text-white serif leading-[0.9] mb-4">
            {config.content.heroTitle}
          </h2>
          <div className="flex items-center gap-6 mb-10">
             <div className="h-px w-12 md:w-24 bg-[var(--brand-champagne)]/30"></div>
             <span className="script-font text-[var(--brand-champagne)] text-5xl md:text-7xl lowercase">{config.content.heroSubtitle}</span>
             <div className="h-px w-12 md:w-24 bg-[var(--brand-champagne)]/30"></div>
          </div>

          <p className="text-zinc-300 text-sm md:text-base max-w-xl mx-auto font-light leading-relaxed tracking-wide mb-14">
            The quintessence of Bengal’s heritage. Artisanal treasures, silk-wrapped and wax-sealed for the discerning few.
          </p>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <button 
              onClick={() => scrollToSection('boutique')}
              className="bg-[var(--brand-champagne)] text-[var(--brand-plum)] px-10 py-4 rounded-sm font-bold uppercase tracking-[0.25em] text-[10px] hover:bg-white hover:shadow-[0_0_30px_rgba(244,235,208,0.3)] hover:scale-105 active:scale-95 transition-all duration-500 min-w-[200px]"
            >
              Explore Boutique
            </button>
            
            {config.features.showRitual && (
              <button 
                onClick={() => setIsRitualOpen(true)}
                className="bg-transparent border border-[var(--brand-champagne)]/40 text-[var(--brand-champagne)] px-10 py-4 rounded-sm font-bold uppercase tracking-[0.25em] text-[10px] hover:border-[var(--brand-champagne)] hover:bg-[var(--brand-champagne)]/5 hover:scale-105 active:scale-95 transition-all duration-500 min-w-[200px] flex items-center justify-center gap-2 group"
              >
                Our Ritual <Feather size={14} className="group-hover:translate-x-1 transition-transform opacity-60" />
              </button>
            )}
          </div>
        </div>
        
        <div 
          onClick={() => scrollToSection('boutique')}
          className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-6 opacity-60 cursor-pointer hover:opacity-100 transition-opacity"
        >
           <span className="text-[8px] uppercase tracking-[0.4em] text-[var(--brand-champagne)] font-light">Begin Journey</span>
           <div className="w-px h-24 bg-gradient-to-b from-[var(--brand-champagne)] to-transparent"></div>
        </div>
      </section>

      {/* Ritual Modal Overlay */}
      {isRitualOpen && config.features.showRitual && (
        <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-500">
          <button 
            onClick={() => setIsRitualOpen(false)} 
            className="absolute top-8 right-8 text-zinc-500 hover:text-[var(--brand-champagne)] transition-colors p-2 hover:rotate-90 duration-300"
          >
            <X size={32} strokeWidth={1} />
          </button>
          
          <div className="max-w-5xl w-full flex flex-col items-center justify-center text-center animate-in zoom-in-95 duration-500">
            <div className="relative w-full aspect-video bg-[#0c0c0e] rounded-[2rem] overflow-hidden border border-[var(--brand-champagne)]/10 group cursor-pointer shadow-2xl">
              {/* Video Placeholder Background */}
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1607082349566-187342175e2f?q=80&w=2000')] bg-cover bg-center opacity-40 group-hover:scale-105 transition-transform duration-[2s]"></div>
              <div className="absolute inset-0 bg-black/40"></div>
              
              <div className="relative z-10 flex flex-col items-center justify-center h-full space-y-8 p-12">
                <div className="w-20 h-20 rounded-full border border-[var(--brand-champagne)]/30 flex items-center justify-center backdrop-blur-md group-hover:scale-110 transition-transform duration-500 bg-[var(--brand-champagne)]/10 text-[var(--brand-champagne)]">
                  <Play size={28} fill="currentColor" className="ml-1" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-4xl md:text-5xl serif italic text-[var(--brand-champagne)]">The Art of Unboxing</h3>
                  <p className="text-zinc-300 text-sm max-w-md mx-auto leading-relaxed font-light tracking-wide">
                    Witness the meticulous craft behind every Bahari Box. From the hand-folded silk paper to the signature wax seal, it is not just a package—it is a ceremony.
                  </p>
                </div>
              </div>
            </div>
            <p className="mt-8 text-[9px] uppercase tracking-[0.3em] text-zinc-500 font-bold">
              Duration: 01:45 • Shot in Dhaka Atelier
            </p>
          </div>
        </div>
      )}

      {/* Product Grid with Filter */}
      <section id="boutique" className="max-w-7xl mx-auto px-8 py-40 space-y-24 scroll-mt-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-12 border-b border-[var(--brand-champagne)]/10 pb-8">
          <div>
            <span className="text-[var(--brand-champagne)] text-[9px] font-black uppercase tracking-[0.4em] mb-4 block flex items-center gap-2">
               <div className="w-4 h-px bg-[var(--brand-champagne)]"></div> Selected Treasures
            </span>
            <h3 className="text-5xl font-medium serif text-white">The Asset Ledger</h3>
          </div>
          <div className="flex gap-6 overflow-x-auto pb-2 md:pb-0 custom-scrollbar">
            {['All', ...categories.map(c => c.name)].map((tab, i) => (
              <button 
                key={tab} 
                onClick={() => setActiveCategory(tab)}
                className={`text-[10px] uppercase font-bold tracking-[0.2em] transition-all pb-2 whitespace-nowrap ${activeCategory === tab ? 'text-[var(--brand-champagne)] border-b border-[var(--brand-champagne)]' : 'text-zinc-500 hover:text-white'}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center space-y-4">
             <Feather size={48} className="mx-auto text-zinc-700" />
             <p className="text-zinc-500 text-sm font-light">No treasures found matching your desires.</p>
             <button onClick={() => { setSearchQuery(''); setActiveCategory('All'); }} className="text-[var(--brand-champagne)] text-xs font-bold uppercase tracking-widest hover:underline">Clear Filters</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {filteredProducts.map((product) => (
              <div key={product.id} className="group relative flex flex-col">
                {/* Product Image */}
                <div className="relative aspect-[3/4] overflow-hidden mb-8 bg-[#0A0508] border border-[var(--brand-champagne)]/5">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    onError={(e) => e.currentTarget.src = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400'}
                    className={`w-full h-full object-cover transition-transform duration-[1.5s] ease-in-out group-hover:scale-105 ${product.stock === 0 ? 'grayscale opacity-40' : ''}`}
                  />
                  
                  {product.stock === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center z-20">
                      <span className="bg-[var(--brand-plum)]/90 text-[var(--brand-champagne)] px-6 py-3 text-[9px] font-black uppercase tracking-[0.3em] border border-[var(--brand-champagne)]/20">Inventory Depleted</span>
                    </div>
                  )}
                  
                  {product.isHot && product.stock > 0 && (
                    <div className="absolute top-4 left-4 bg-[var(--brand-champagne)] text-[var(--brand-plum)] px-4 py-1.5 text-[8px] font-bold uppercase tracking-[0.2em] z-20">
                      Exclusive
                    </div>
                  )}

                  {/* Quick Actions Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10 flex flex-col justify-end p-6">
                    <div className="flex justify-between items-end translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                      <button 
                         onClick={() => onQuickView(product)}
                         className="bg-white/10 hover:bg-[var(--brand-champagne)] hover:text-[var(--brand-plum)] text-white p-3 rounded-full backdrop-blur-md transition-all duration-300"
                         title="Quick View"
                      >
                        <Eye size={18} strokeWidth={1.5} />
                      </button>
                      
                      <button 
                         onClick={(e) => handleShare(product, e)}
                         className="bg-white/10 hover:bg-[var(--brand-champagne)] hover:text-[var(--brand-plum)] text-white p-3 rounded-full backdrop-blur-md transition-all duration-300"
                         title="Share"
                      >
                        <Share2 size={18} strokeWidth={1.5} />
                      </button>

                      <button 
                         onClick={() => onToggleWishlist(product.id)}
                         className={`bg-white/10 hover:bg-[var(--brand-champagne)] hover:text-[var(--brand-plum)] p-3 rounded-full backdrop-blur-md transition-all duration-300 ${wishlistIds.includes(product.id) ? 'text-rose-500 bg-white/20' : 'text-white'}`}
                         title="Add to Wishlist"
                      >
                        <Heart size={18} strokeWidth={1.5} className={wishlistIds.includes(product.id) ? "fill-current" : ""} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 space-y-3 text-center">
                  <span className="text-[8px] uppercase tracking-[0.3em] text-[var(--brand-champagne)]/60 block">{product.category}</span>
                  <h4 
                    className="text-2xl font-medium serif text-white group-hover:text-[var(--brand-champagne)] transition-colors cursor-pointer"
                    onClick={() => onQuickView(product)}
                  >
                    {product.name}
                  </h4>
                  <div className="flex items-center justify-center gap-4 text-[var(--brand-champagne)]">
                     <span className="text-sm font-bold tracking-widest">{TAKA_SIGN}{product.price.toLocaleString()}</span>
                  </div>
                </div>

                {/* Purchase Button - Minimal Text */}
                <button 
                  onClick={() => product.stock > 0 && onAddToCart(product)}
                  disabled={product.stock === 0}
                  className="mt-6 text-[9px] uppercase tracking-[0.3em] font-bold text-zinc-500 hover:text-white transition-colors group-hover:translate-y-0 translate-y-2 opacity-0 group-hover:opacity-100 duration-700"
                >
                  {product.stock > 0 ? 'Add to Box' : 'Waitlist'}
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer id="footer" className="border-t border-[var(--brand-champagne)]/10 bg-[var(--brand-noir)] py-24 px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-24">
          <div className="space-y-8">
            <h4 className="text-4xl serif text-[var(--brand-champagne)]">Bahari Box</h4>
            <p className="text-zinc-500 text-xs leading-loose font-light tracking-wide max-w-xs">
              Crafting premium unboxing rituals for the most discerning Patrons. Unboxing love across all 64 districts of Bangladesh.
            </p>
          </div>
          <div>
            <h5 className="text-[9px] uppercase font-bold tracking-[0.3em] text-white mb-8">Boutique</h5>
            <ul className="space-y-4 text-xs text-zinc-500 font-light tracking-wide">
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">Asset Ledger</button></li>
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">Bespoke Rituals</button></li>
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">Track Surprise</button></li>
            </ul>
          </div>
          <div>
            <h5 className="text-[9px] uppercase font-bold tracking-[0.3em] text-white mb-8">Concierge</h5>
            <ul className="space-y-4 text-xs text-zinc-500 font-light tracking-wide">
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">WhatsApp Desk</button></li>
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">Corporate Gifting</button></li>
              <li><button className="hover:text-[var(--brand-champagne)] transition-colors">Delivery Registry</button></li>
            </ul>
          </div>
          <div>
             <h5 className="text-[9px] uppercase font-bold tracking-[0.3em] text-white mb-8">Atelier</h5>
             <div className="flex items-center gap-3 text-zinc-500 text-xs mb-4 font-light">
                <MapPin size={14} className="text-[var(--brand-champagne)]" />
                <span>Gulshan 2, Dhaka, BD</span>
             </div>
             <div className="flex items-center gap-3 text-zinc-500 text-xs font-light">
                <ShieldCheck size={14} className="text-[var(--brand-champagne)]" />
                <span>Verified Artisan Registry</span>
             </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6 border-t border-[var(--brand-champagne)]/5 pt-12">
          <p className="text-[8px] uppercase tracking-[0.3em] text-zinc-600 font-bold">
            © 2024 BAHARI BOX LUXURY RETAIL.
          </p>
          <div className="flex gap-10">
             <button className="text-[8px] uppercase tracking-[0.3em] text-zinc-600 hover:text-[var(--brand-champagne)] transition-colors font-bold">Privacy</button>
             <button className="text-[8px] uppercase tracking-[0.3em] text-zinc-600 hover:text-[var(--brand-champagne)] transition-colors font-bold">Terms</button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;
