
import React, { useState } from 'react';
import { X, Search, Truck, Package, CheckCircle2, MapPin, Loader2, Sparkles } from 'lucide-react';
import { translations } from '../translations';

interface TrackOrderPanelProps {
  isOpen: boolean;
  onClose: () => void;
  t: (key: keyof typeof translations.en) => string;
}

type OrderStatus = 'preparing' | 'shipped' | 'delivered';

const TrackOrderPanel: React.FC<TrackOrderPanelProps> = ({ isOpen, onClose, t }) => {
  const [orderId, setOrderId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ id: string; status: OrderStatus } | null>(null);
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId.trim()) return;

    setIsLoading(true);
    setError(false);
    setResult(null);

    // Simulated tracking logic
    setTimeout(() => {
      setIsLoading(false);
      if (orderId.toUpperCase().startsWith('BB-')) {
        const statuses: OrderStatus[] = ['preparing', 'shipped', 'delivered'];
        setResult({
          id: orderId.toUpperCase(),
          status: statuses[Math.floor(Math.random() * statuses.length)]
        });
      } else {
        setError(true);
      }
    }, 1500);
  };

  const statusInfo = {
    preparing: { icon: <Package size={32} />, label: t('status_preparing'), step: 1 },
    shipped: { icon: <Truck size={32} />, label: t('status_shipped'), step: 2 },
    delivered: { icon: <CheckCircle2 size={32} />, label: t('status_delivered'), step: 3 },
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="absolute inset-0" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-xl rounded-[3rem] overflow-hidden shadow-2xl animate-in zoom-in duration-500 p-8 lg:p-12">
        <button onClick={onClose} className="absolute top-8 right-8 p-2 bg-slate-50 hover:bg-slate-100 rounded-full text-slate-400 transition-all">
          <X size={20} />
        </button>

        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-[#5b2b4d]/10 text-[#5b2b4d] rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Truck size={32} strokeWidth={1.5} />
          </div>
          <h2 className="text-3xl font-bold text-slate-800 serif italic mb-3">{t('track_order_title')}</h2>
          <p className="text-slate-500 text-sm leading-relaxed max-w-xs mx-auto">{t('track_order_desc')}</p>
        </div>

        <form onSubmit={handleTrack} className="mb-10">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                placeholder={t('order_number_placeholder')}
                className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-4 pl-6 pr-6 focus:bg-white focus:outline-none focus:border-[#5b2b4d]/20 transition-all font-bold text-slate-800"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="bg-[#5b2b4d] text-white px-8 py-4 rounded-2xl font-bold hover:bg-[#4a233f] transition-all flex items-center justify-center gap-2 shadow-xl shadow-[#5b2b4d]/20 disabled:opacity-70"
            >
              {isLoading ? <Loader2 size={20} className="animate-spin" /> : t('track_btn')}
            </button>
          </div>
          {error && (
            <p className="mt-4 text-rose-500 text-xs font-bold text-center">{t('tracking_not_found')}</p>
          )}
        </form>

        {result && (
          <div className="bg-slate-50 rounded-[2.5rem] p-8 border border-slate-100 animate-in slide-in-from-bottom-5 duration-500">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-200">
               <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{t('order_number_label')}</span>
               <span className="font-black text-[#5b2b4d]">{result.id}</span>
            </div>

            <div className="relative">
              {/* Progress Line */}
              <div className="absolute left-[23px] top-6 bottom-6 w-0.5 bg-slate-200">
                <div 
                  className="w-full bg-emerald-500 transition-all duration-1000 ease-out" 
                  style={{ height: result.status === 'preparing' ? '0%' : result.status === 'shipped' ? '50%' : '100%' }}
                />
              </div>

              <div className="space-y-10">
                {(['preparing', 'shipped', 'delivered'] as OrderStatus[]).map((st) => {
                  const isActive = result.status === st || (st === 'preparing' && (result.status === 'shipped' || result.status === 'delivered')) || (st === 'shipped' && result.status === 'delivered');
                  const isCurrent = result.status === st;

                  return (
                    <div key={st} className={`flex items-center gap-6 relative z-10 ${isActive ? 'opacity-100' : 'opacity-40'}`}>
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 ${isActive ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'bg-white text-slate-300 border-2 border-slate-100'}`}>
                        {isActive ? <CheckCircle2 size={24} /> : statusInfo[st].icon}
                      </div>
                      <div>
                        <h4 className={`text-sm font-bold uppercase tracking-widest ${isActive ? 'text-slate-800' : 'text-slate-400'}`}>
                          {statusInfo[st].label}
                        </h4>
                        {isCurrent && (
                          <div className="flex items-center gap-2 mt-1">
                             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></div>
                             <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Live Updates</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrackOrderPanel;
