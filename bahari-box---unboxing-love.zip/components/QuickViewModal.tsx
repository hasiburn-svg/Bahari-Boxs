
import React, { useState, useEffect, useMemo } from 'react';
import { X, ShoppingBag, Star, Sparkles, ShieldCheck, CheckCircle2, SlidersHorizontal, Maximize2, ChevronLeft, ChevronRight, Share2 } from 'lucide-react';
import { Product } from '../types';
import { translations } from '../translations';

const TAKA_SIGN = '\u09F3';
const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (p: Product) => void;
  t: (key: keyof typeof translations.en) => string;
}

const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose, onAddToCart, t }) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Reset index when product changes
  useEffect(() => {
    setActiveImageIndex(0);
  }, [product]);

  // Combine main image and gallery images into a single array
  const images = useMemo(() => {
    if (!product) return [];
    // Ensure the main image is always first, then gallery items
    return [product.image, ...(product.gallery || [])].filter(Boolean);
  }, [product]);

  const handleShare = async () => {
    if (!product) return;
    
    let shareUrl = window.location.href;
    try {
        const baseUrl = window.location.origin + window.location.pathname;
        const urlObj = new URL(baseUrl);
        urlObj.searchParams.set('product', product.id);
        shareUrl = urlObj.toString();
    } catch (error) {
        shareUrl = window.location.href; 
    }

    const shareData = {
      title: `Bahari Box - ${product.name}`,
      text: `Check out ${product.name} at Bahari Box.`,
      url: shareUrl,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        throw new Error('Web Share API not supported');
      }
    } catch (err) {
      try {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        alert('Link copied to clipboard!');
      } catch (clipboardErr) {
        console.error('Clipboard failed:', clipboardErr);
      }
    }
  };

  if (!product) return null;

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      <div className="relative bg-[#0c0c0e] rounded-[2rem] w-full max-w-4xl h-auto md:h-[600px] overflow-hidden shadow-[0_0_50px_rgba(91,43,77,0.25)] flex flex-col md:flex-row animate-in zoom-in-95 duration-500 border border-[#5b2b4d]/30 ring-1 ring-white/5">
        
        {/* Share Button */}
        <button 
          onClick={handleShare} 
          className="absolute top-4 right-16 z-50 p-2 bg-white/5 text-zinc-400 rounded-full hover:bg-[#5b2b4d] hover:text-white transition-all border border-white/5"
          title="Share"
        >
          <Share2 size={18} />
        </button>

        {/* Close Button */}
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 z-50 p-2 bg-white/5 text-zinc-400 rounded-full hover:bg-[#5b2b4d] hover:text-white transition-all border border-white/5"
        >
          <X size={18} />
        </button>

        {/* Left: Image Panel */}
        <div className="md:w-5/12 bg-[#050505] relative flex flex-col justify-center items-center p-8 group select-none">
          <div className="relative w-full aspect-square rounded-xl overflow-hidden shadow-2xl border border-white/5 bg-[#0c0c0e]">
             {images.map((img, idx) => (
                <img 
                  key={idx}
                  src={img || FALLBACK_IMAGE}
                  onError={(e) => {
                    e.currentTarget.onerror = null; // Prevent infinite loop
                    e.currentTarget.src = FALLBACK_IMAGE;
                  }}
                  alt={`${product.name} view ${idx + 1}`} 
                  className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-in-out transform ${idx === activeImageIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-110 pointer-events-none'}`} 
                />
             ))}
             
             <button className="absolute top-3 right-3 p-2 bg-black/50 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm hover:bg-[#5b2b4d] z-10">
                <Maximize2 size={14} />
             </button>

             {/* Navigation Arrows */}
             {images.length > 1 && (
               <>
                 <button 
                   onClick={prevImage}
                   className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-black/30 hover:bg-black/60 text-white rounded-full backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all transform hover:scale-110"
                 >
                   <ChevronLeft size={18} />
                 </button>
                 <button 
                   onClick={nextImage}
                   className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-black/30 hover:bg-black/60 text-white rounded-full backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all transform hover:scale-110"
                 >
                   <ChevronRight size={18} />
                 </button>
               </>
             )}
          </div>
          
          {/* Gallery Dots */}
          {images.length > 1 && (
            <div className="flex gap-2 mt-6">
               {images.map((_, idx) => (
                 <button
                   key={idx}
                   onClick={() => setActiveImageIndex(idx)}
                   className={`w-2 h-2 rounded-full transition-all duration-300 ${idx === activeImageIndex ? 'bg-[#5b2b4d] w-4 scale-110 shadow-[0_0_8px_#5b2b4d]' : 'bg-zinc-800 hover:bg-zinc-600'}`}
                   aria-label={`View image ${idx + 1}`}
                 />
               ))}
            </div>
          )}
        </div>
        
        {/* Right: Content Panel */}
        <div className="md:w-7/12 p-8 md:p-10 flex flex-col text-white overflow-y-auto custom-scrollbar">
          
          {/* Header Info */}
          <div className="mb-6">
             <div className="flex items-center gap-3 mb-2">
                <div className="w-0.5 h-3 bg-[#5b2b4d]"></div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">
                  {product.category}
                </span>
             </div>
             <h2 className="text-3xl md:text-4xl font-medium serif tracking-tight mb-3">
               {product.name}
             </h2>
             
             <div className="flex items-center gap-4">
                <div className="flex text-amber-400 gap-0.5">
                   {[...Array(5)].map((_, i) => (
                      <Star key={i} size={12} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} />
                   ))}
                </div>
                <div className="w-px h-3 bg-zinc-700"></div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">
                  {product.reviews} {t('verified_reviews')}
                </span>
             </div>
          </div>

          <div className="text-3xl font-medium serif text-white mb-6">
            {TAKA_SIGN}{product.price.toLocaleString()}
          </div>

          {/* Description Box */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/5 mb-8">
             <p className="text-zinc-400 text-xs leading-relaxed font-light mb-4">
               {product.description || t('quick_view_desc')}
             </p>
             
             <div className="space-y-2">
                <h5 className="text-[10px] font-bold uppercase tracking-widest text-zinc-300 flex items-center gap-2">
                   <ShieldCheck size={12} className="text-emerald-500" /> Product Specifications
                </h5>
                <ul className="text-[10px] text-zinc-500 space-y-1 list-disc list-inside">
                   <li>Dimensions: Hand-picked, Sustainable</li>
                   <li>Materials: Premium Artisanal Sourcing</li>
                   <li>Presentation: Signature Bahari Wrap</li>
                </ul>
             </div>
          </div>
          
          <div className="mt-auto space-y-4">
             <button 
                onClick={() => { onAddToCart(product); onClose(); }}
                disabled={product.stock === 0}
                className="w-full bg-[#5b2b4d] hover:bg-[#4a233f] text-white py-4 rounded-xl font-bold uppercase tracking-[0.2em] text-xs transition-all shadow-lg shadow-[#5b2b4d]/20 active:scale-[0.98] flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
             >
                <ShoppingBag size={16} /> 
                {product.stock === 0 ? 'Out of Stock' : t('add_to_box')}
             </button>
             
             <div className="flex items-center justify-center gap-2 text-[9px] font-bold uppercase tracking-widest text-zinc-500">
                <Sparkles size={10} className="text-[#5b2b4d]" /> Personalize Available Today
             </div>

             <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <div className="flex items-center gap-2 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20">
                   <CheckCircle2 size={12} className="text-emerald-500" />
                   <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-500">Authentic Product</span>
                </div>
                <div className="flex items-center gap-2 bg-[#5b2b4d]/10 px-3 py-1.5 rounded-lg border border-[#5b2b4d]/20">
                   <SlidersHorizontal size={12} className="text-[#5b2b4d]" />
                   <span className="text-[9px] font-bold uppercase tracking-wider text-[#5b2b4d]">Custom Options</span>
                </div>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default QuickViewModal;
