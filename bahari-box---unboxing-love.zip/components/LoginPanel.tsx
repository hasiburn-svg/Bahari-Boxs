
import React, { useState } from 'react';
import { 
  X, Mail, Lock, User, ArrowRight, Gift, Sparkles, 
  ChevronRight, Apple, Loader2, ShieldCheck, Github, 
  MessageCircle, Info
} from 'lucide-react';
import { translations } from '../translations';

interface LoginPanelProps {
  isOpen: boolean;
  onClose: () => void;
  t: (key: keyof typeof translations.en) => string;
}

type ViewState = 'login' | 'register' | 'forgot';

const LoginPanel: React.FC<LoginPanelProps> = ({ isOpen, onClose, t }) => {
  const [view, setView] = useState<ViewState>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center p-0 md:p-6 lg:p-10 animate-in fade-in duration-300">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onClose}></div>
      
      {/* Content Container */}
      <div className="relative bg-white w-full max-w-6xl h-full md:h-[90vh] md:max-h-[850px] md:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row animate-in zoom-in slide-in-from-bottom-12 duration-500">
        
        {/* Close Button (Mobile Only Top) */}
        <button onClick={onClose} className="lg:hidden absolute top-6 right-6 z-50 p-3 bg-slate-100 rounded-full text-slate-400">
          <X size={20} />
        </button>

        {/* Left Side: Brand Imagery & Messaging */}
        <div className="hidden lg:flex lg:w-5/12 bg-[#5b2b4d] relative overflow-hidden p-16 flex-col justify-between text-white">
          {/* Animated Background Decoration */}
          <div className="absolute -top-20 -left-20 w-80 h-80 bg-white/5 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl"></div>
          
          <div className="relative z-10 space-y-12">
            <div className="flex items-center gap-3">
              <div className="bg-white text-[#5b2b4d] p-2 rounded-xl shadow-lg">
                <Gift size={24} />
              </div>
              <span className="text-2xl font-bold tracking-tighter">Bahari Box</span>
            </div>

            <div className="space-y-6">
              <h2 className="text-5xl font-medium leading-tight serif italic animate-in slide-in-from-left-10 duration-700">
                {view === 'login' && t('welcome_back')}
                {view === 'register' && t('begin_journey')}
                {view === 'forgot' && t('reset_password')}
              </h2>
              <p className="text-purple-200/80 text-lg font-medium max-w-sm leading-relaxed">
                Join our exclusive circle of thoughtful gifters and artisans across Bangladesh.
              </p>
            </div>
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-4 p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl">
              <ShieldCheck className="text-emerald-400 shrink-0" size={28} />
              <div className="text-[11px] uppercase tracking-widest font-black leading-relaxed">
                Encrypted & Secure Login <br/>
                <span className="text-purple-300/60 font-medium">Protecting your unboxing moments.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Clean Form Area */}
        <div className="flex-1 bg-white p-8 lg:p-20 flex flex-col justify-center overflow-y-auto custom-scrollbar">
          <div className="max-w-md mx-auto w-full space-y-10">
            
            {/* Form Header */}
            <div className="text-center lg:text-left space-y-3">
              <h3 className="text-3xl font-bold text-slate-800 tracking-tight">
                {view === 'login' && t('sign_in')}
                {view === 'register' && t('create_account')}
                {view === 'forgot' && t('reset_password')}
              </h3>
              <p className="text-slate-400 text-sm font-medium">
                {view === 'login' && (
                  <>
                    <button onClick={() => setView('register')} className="text-[#5b2b4d] font-bold hover:underline transition-all">
                      {t('join_now')}
                    </button>
                  </>
                )}
                {view === 'register' && (
                  <>
                    <button onClick={() => setView('login')} className="text-[#5b2b4d] font-bold hover:underline transition-all">
                      {t('already_member')}
                    </button>
                  </>
                )}
                {view === 'forgot' && (
                  <>
                    <button onClick={() => setView('login')} className="text-[#5b2b4d] font-bold hover:underline transition-all">
                      Back to Sign In
                    </button>
                  </>
                )}
              </p>
            </div>

            {/* Form */}
            <form className="space-y-6" onSubmit={handleSubmit}>
              {view === 'register' && (
                <div className="relative group animate-in slide-in-from-top-4 duration-300">
                  <User className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#5b2b4d] transition-colors" size={18} />
                  <input required type="text" placeholder="Your Name" className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-5 pl-16 pr-6 focus:bg-white focus:outline-none focus:border-[#5b2b4d]/20 transition-all font-semibold text-slate-800" />
                </div>
              )}

              <div className="relative group">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#5b2b4d] transition-colors" size={18} />
                <input required type="email" placeholder="Email Address" className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-5 pl-16 pr-6 focus:bg-white focus:outline-none focus:border-[#5b2b4d]/20 transition-all font-semibold text-slate-800" />
              </div>

              {view !== 'forgot' && (
                <div className="relative group">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[#5b2b4d] transition-colors" size={18} />
                  <input required type={showPassword ? "text" : "password"} placeholder="Password" className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-5 pl-16 pr-6 focus:bg-white focus:outline-none focus:border-[#5b2b4d]/20 transition-all font-semibold text-slate-800" />
                  <button 
                    type="button" 
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 font-black uppercase text-[9px] tracking-widest"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              )}

              {view === 'login' && (
                <div className="flex items-center justify-between px-1">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input type="checkbox" className="w-5 h-5 rounded-md border-slate-200 text-[#5b2b4d] focus:ring-[#5b2b4d]/20" />
                    <span className="text-xs font-bold text-slate-400 group-hover:text-slate-600 transition-colors">{t('remember_me')}</span>
                  </label>
                  <button type="button" onClick={() => setView('forgot')} className="text-xs font-bold text-[#5b2b4d] hover:underline">
                    {t('forgot_password')}
                  </button>
                </div>
              )}

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-[#5b2b4d] text-white py-5 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-[#4a233f] transition-all shadow-xl shadow-[#5b2b4d]/20 active:scale-[0.98] disabled:opacity-70 group"
              >
                {isLoading ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : (
                  <>
                    <span className="uppercase tracking-[0.2em] text-xs font-black">
                      {view === 'login' && t('step_inside')}
                      {view === 'register' && t('create_profile')}
                      {view === 'forgot' && t('reset_password')}
                    </span>
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </form>

            {/* Social Login Separator */}
            {view !== 'forgot' && (
              <div className="space-y-8">
                <div className="relative flex items-center justify-center">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-100"></div>
                  </div>
                  <span className="relative px-4 bg-white text-[10px] font-black uppercase tracking-[0.3em] text-slate-300">
                    {t('social_login_desc')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button className="flex items-center justify-center gap-3 py-4 border-2 border-slate-50 rounded-2xl hover:border-[#5b2b4d]/10 hover:bg-slate-50 transition-all font-bold text-sm text-slate-700">
                    <img src="https://www.svgrepo.com/show/355037/google.svg" className="w-5 h-5" alt="Google" />
                    Google
                  </button>
                  <button className="flex items-center justify-center gap-3 py-4 border-2 border-slate-50 rounded-2xl hover:border-[#5b2b4d]/10 hover:bg-slate-50 transition-all font-bold text-sm text-slate-700">
                    <Apple size={20} className="text-slate-900" />
                    Apple
                  </button>
                </div>
              </div>
            )}

            {/* Guest Checkout Option */}
            <div className="pt-10 flex flex-col items-center">
              <button 
                onClick={onClose}
                className="group flex items-center gap-3 text-slate-400 hover:text-[#5b2b4d] transition-all"
              >
                <span className="text-xs font-black uppercase tracking-[0.2em]">{t('checkout_guest')}</span>
                <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPanel;
