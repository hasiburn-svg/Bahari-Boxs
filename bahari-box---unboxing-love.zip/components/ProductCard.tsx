
import React from 'react';
import { Heart, Eye, Star, Gift } from 'lucide-react';
import { Product } from '../types';
import { translations } from '../translations';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549465220-1d8c9d9c4740?q=80&w=400';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  onQuickView: (p: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (id: string) => void;
  t: (key: keyof typeof translations.en) => string;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onAddToCart, 
  onQuickView, 
  isWishlisted, 
  onToggleWishlist,
  t
}) => {
  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div className="bg-white border border-purple-50 rounded-3xl p-5 group hover:shadow-2xl transition-all duration-500 relative overflow-hidden flex flex-col h-full border-b-4 border-b-transparent hover:border-b-[#5b2b4d]">
      <div className="absolute top-5 left-5 flex flex-col gap-2 z-10">
        {discount && <span className="bg-rose-500 text-white text-[9px] font-bold px-2 py-1 rounded-full">-{discount}% {t('off')}</span>}
        {product.isHot && <span className="bg-[#5b2b4d] text-white text-[9px] font-bold px-2 py-1 rounded-full">{t('trending')}</span>}
        {product.isNew && <span className="bg-purple-100 text-[#5b2b4d] text-[9px] font-bold px-2 py-1 rounded-full border border-[#5b2b4d]/10">{t('limited')}</span>}
      </div>

      <div className="relative aspect-[4/5] mb-5 overflow-hidden rounded-2xl cursor-pointer" onClick={() => onQuickView(product)}>
        <img 
          src={product.image || FALLBACK_IMAGE} 
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = FALLBACK_IMAGE;
          }}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" 
          alt={product.name} 
        />
      </div>

      <div className="flex-1 flex flex-col">
        <span className="text-[10px] font-bold uppercase tracking-widest text-purple-400 mb-2">{product.category}</span>
        <h3 className="font-bold text-gray-800 text-base mb-2 hover:text-[#5b2b4d] cursor-pointer transition-colors leading-snug" onClick={() => onQuickView(product)}>{product.name}</h3>
        <div className="flex items-center gap-2 mb-4">
          <div className="flex text-rose-400">
            {[...Array(5)].map((_, i) => <Star key={i} size={13} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} />)}
          </div>
          <span className="text-[11px] font-medium text-gray-400">{product.reviews} {t('reviews')}</span>
        </div>
        <div className="mt-auto">
          <div className="flex items-center gap-3 mb-5">
            <span className="text-[#5b2b4d] font-bold text-xl">৳{product.price.toLocaleString()}</span>
          </div>
          <button onClick={() => onAddToCart(product)} className="w-full bg-purple-50 text-[#5b2b4d] hover:bg-[#5b2b4d] hover:text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all">
            <Gift size={18} /> {t('add_to_box')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
