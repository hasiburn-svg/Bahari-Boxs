
import React from 'react';
import { 
  Gift, 
  Sparkles, 
  Coffee, 
  Moon, 
  Heart, 
  Flower2, 
  Gem, 
  Star,
  Package,
  PartyPopper,
  MapPin,
  Truck,
  ShieldCheck
} from 'lucide-react';
import { Category, Product } from './types';

// Using Unicode for Taka sign to avoid encoding issues in various environments
const TAKA_SIGN = '\u09F3';

export const BANGLADESH_DISTRICTS = [
  "Bagerhat", "Bandarban", "Barguna", "Barishal", "Bhola", "Bogura", "Brahmanbaria", "Chandpur", "Chapainawabganj", "Chattogram", "Chuadanga", "Cumilla", "Cox's Bazar", "Dhaka", "Dinajpur", "Faridpur", "Feni", "Gaibandha", "Gazipur", "Gopalganj", "Habiganj", "Jamalpur", "Jashore", "Jhalokati", "Jhenaidah", "Joypurhat", "Khagrachhari", "Khulna", "Kishoreganj", "Kurigram", "Kushtia", "Lakshmipur", "Lalmonirhat", "Madaripur", "Magura", "Manikganj", "Meherpur", "Moulvibazar", "Munshiganj", "Mymensingh", "Naogaon", "Narail", "Narayanganj", "Narsingdi", "Natore", "Netrokona", "Nilphamari", "Noakhali", "Pabna", "Panchagarh", "Patuakhali", "Pirojpur", "Rajbari", "Rajshahi", "Rangamati", "Rangpur", "Satkhira", "Shariatpur", "Sherpur", "Sirajganj", "Sunamganj", "Sylhet", "Tangail", "Thakurgaon"
].sort();

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'Signature Boxes', icon: 'Gift', count: 0 },
  { id: '2', name: 'Self-Care & Spa', icon: 'Sparkles', count: 0 },
  { id: '3', name: 'Morning Brews', icon: 'Coffee', count: 0 },
  { id: '4', name: 'Sleep & Serenity', icon: 'Moon', count: 0 },
  { id: '5', name: 'Romantic Gestures', icon: 'Heart', count: 0 },
  { id: '6', name: 'Floral Delights', icon: 'Flower2', count: 0 },
  { id: '7', name: 'Artisan Treasures', icon: 'Gem', count: 0 },
  { id: '8', name: 'Celebration Kits', icon: 'PartyPopper', count: 0 },
];

export const PRODUCTS: Product[] = [];

export const AVAILABLE_ICONS = ['Gift', 'Sparkles', 'Coffee', 'Moon', 'Heart', 'Flower2', 'Gem', 'Star', 'Package', 'PartyPopper'];

export const getCategoryIcon = (iconName: string) => {
  const icons: Record<string, React.ReactNode> = {
    Gift: <Gift className="w-5 h-5" />,
    Sparkles: <Sparkles className="w-5 h-5" />,
    Coffee: <Coffee className="w-5 h-5" />,
    Moon: <Moon className="w-5 h-5" />,
    Heart: <Heart className="w-5 h-5" />,
    Flower2: <Flower2 className="w-5 h-5" />,
    Gem: <Gem className="w-5 h-5" />,
    Star: <Star className="w-5 h-5" />,
    Package: <Package className="w-5 h-5" />,
    PartyPopper: <PartyPopper className="w-5 h-5" />,
  };
  return icons[iconName] || <Gift className="w-5 h-5" />;
};
